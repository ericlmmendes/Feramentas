import pygame
import sys

pygame.init()
pygame.mixer.init()

# Configurações da tela
LARGURA, ALTURA = 1200, 700
tela = pygame.display.set_mode((LARGURA, ALTURA))
pygame.display.set_caption("Sistema de Chicote - Pressione ESPAÇO para ativar")
clock = pygame.time.Clock()

# Carrega recursos
try:
    whip_img = pygame.image.load("whip.png").convert_alpha()
    whip_img = pygame.transform.scale(whip_img, (80, 120))  # ajuste o tamanho
    som_chicote = pygame.mixer.Sound("whip_crack.wav")
except:
    print("Erro ao carregar imagem ou som. Crie arquivos whip.png e whip_crack.wav")
    whip_img = None
    som_chicote = None

# Variáveis
ativado = False
mouse_pos = (0, 0)
animando = False
frame_anim = 0
anim_timer = 0
rastro = []  # para efeito visual da chicotada

# Cores
BRANCO = (255, 255, 255)
VERMELHO = (255, 50, 50)

running = True
while running:
    dt = clock.tick(60)  # 60 FPS
    mouse_pos = pygame.mouse.get_pos()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                ativado = not ativado
                if ativado:
                    pygame.mouse.set_visible(False)   # esconde cursor real
                else:
                    pygame.mouse.set_visible(True)

            if ativado and event.key == pygame.K_RETURN:  # tecla Enter
                if som_chicote:
                    som_chicote.play()
                animando = True
                frame_anim = 0
                # Efeito de rastro no ponto do clique
                rastro.append((mouse_pos, 15))  # (posição, tempo de vida)

        if ativado and event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:  # clique esquerdo
            if som_chicote:
                som_chicote.play()
            animando = True
            frame_anim = 0
            rastro.append((mouse_pos, 15))

    # Atualiza animação
    if animando:
        anim_timer += dt
        if anim_timer > 50:  # velocidade da animação (ms)
            frame_anim += 1
            anim_timer = 0
            if frame_anim > 5:  # 6 frames de animação
                animando = False
                frame_anim = 0

    # Atualiza rastro da chicotada
    for i in range(len(rastro)-1, -1, -1):
        pos, vida = rastro[i]
        rastro[i] = (pos, vida - 1)
        if vida <= 0:
            rastro.pop(i)

    # Desenha tudo
    tela.fill((20, 20, 30))  # fundo escuro

    if ativado and whip_img:
        # Desenha o chicote seguindo o mouse (com rotação simples)
        # Rotaciona um pouco para dar sensação de chicote
        angulo = -30 if animando else 0
        whip_rot = pygame.transform.rotate(whip_img, angulo)
        
        # Centraliza a imagem no mouse (ajuste o hotspot)
        rect = whip_rot.get_rect(center=(mouse_pos[0] + 20, mouse_pos[1] + 40))
        tela.blit(whip_rot, rect)

        # Animação de chicotada (estica ou muda cor rapidamente)
        if animando:
            # Desenha um "estalo" extra (linha vermelha rápida)
            if frame_anim < 3:
                pygame.draw.line(tela, VERMELHO, 
                               (mouse_pos[0]-30, mouse_pos[1]-50), 
                               (mouse_pos[0]+80, mouse_pos[1]+60), 8)

    # Desenha rastro da chicotada
    for pos, vida in rastro:
        alpha = int(255 * (vida / 15))
        cor = (*VERMELHO[:3], alpha)  # não funciona direto no pygame, mas simulamos
        tamanho = int(12 * (vida / 15))
        pygame.draw.circle(tela, VERMELHO, pos, tamanho)

    # Texto de instrução
    fonte = pygame.font.SysFont(None, 36)
    txt = fonte.render("ESPAÇO: Ativar/Desativar   |   CLIQUE ou ENTER: Chicotada!", True, BRANCO)
    tela.blit(txt, (10, 10))

    if ativado:
        status = fonte.render("CHICOTE ATIVADO - Divirta-se!", True, (0, 255, 100))
        tela.blit(status, (10, 50))
    else:
        status = fonte.render("Chicote desativado", True, (180, 180, 180))
        tela.blit(status, (10, 50))

    pygame.display.flip()

pygame.quit()
sys.exit()