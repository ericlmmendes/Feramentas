import express from "express";
import path from "path";
import fs from "fs";
import os from "os";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;
const ROOT_DIR = process.cwd();

app.use(express.json());

// Initialize Google GenAI if key is present
let ai: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });
}

// 1. System Info API
app.get("/api/sysinfo", (req, res) => {
  const freeMem = os.freemem();
  const totalMem = os.totalmem();
  const usedMem = totalMem - freeMem;
  const cpuModel = os.cpus()[0]?.model || "Unknown Processor";
  const cpuSpeed = os.cpus()[0]?.speed || 0;
  const cpuCount = os.cpus().length;
  const platform = os.platform();
  const arch = os.arch();
  const uptime = os.uptime();
  
  // Real time stats + simulated tech variables for eDEX-UI style
  res.json({
    platform,
    arch,
    uptime,
    cpu: {
      model: cpuModel,
      speed: cpuSpeed,
      cores: cpuCount,
      load: Math.floor(Math.random() * 20) + 15, // dynamic base load
    },
    memory: {
      total: totalMem,
      used: usedMem,
      free: freeMem,
      percent: Math.round((usedMem / totalMem) * 100),
    },
    disk: {
      total: 100 * 1024 * 1024 * 1024,
      used: 42 * 1024 * 1024 * 1024,
      percent: 42,
    },
    network: {
      ping: Math.floor(Math.random() * 15) + 5,
      bytesReceived: Math.floor(Math.random() * 5000) + 1200,
      bytesSent: Math.floor(Math.random() * 2000) + 400,
    },
    coreTemp: Math.floor(Math.random() * 12) + 48, // °C
    nodeVersion: process.version,
  });
});

// 2. File Explorer API - Safe directory listing
app.post("/api/files", (req, res) => {
  try {
    const relativePath = req.body.path || ".";
    // Resolve safe path
    const safePath = path.resolve(ROOT_DIR, relativePath);
    
    // Check for directory traversal attacks
    if (!safePath.startsWith(ROOT_DIR)) {
      return res.status(403).json({ error: "Access denied. Traversal outside workspace root." });
    }

    if (!fs.existsSync(safePath)) {
      return res.status(404).json({ error: "Path not found." });
    }

    const stat = fs.statSync(safePath);
    if (stat.isDirectory()) {
      const items = fs.readdirSync(safePath);
      const list = items
        .filter(item => !item.startsWith('.') || item === '.gitignore') // hide internal hidden files except .gitignore
        .map(item => {
          const itemPath = path.join(safePath, item);
          const itemStat = fs.statSync(itemPath);
          const relItemPath = path.relative(ROOT_DIR, itemPath) || ".";
          return {
            name: item,
            path: relItemPath,
            isDirectory: itemStat.isDirectory(),
            size: itemStat.size,
            mtime: itemStat.mtime,
          };
        })
        .sort((a, b) => {
          if (a.isDirectory && !b.isDirectory) return -1;
          if (!a.isDirectory && b.isDirectory) return 1;
          return a.name.localeCompare(b.name);
        });

      return res.json({
        isDirectory: true,
        currentPath: path.relative(ROOT_DIR, safePath) || ".",
        items: list,
      });
    } else {
      // It's a file, return its contents
      // Set size threshold to prevent reading massive binaries (e.g., node_modules)
      if (stat.size > 200 * 1024) {
        return res.json({
          isDirectory: false,
          currentPath: path.relative(ROOT_DIR, safePath),
          content: "[Error: File too large to preview in console terminal]",
          size: stat.size,
        });
      }
      
      const content = fs.readFileSync(safePath, "utf-8");
      return res.json({
        isDirectory: false,
        currentPath: path.relative(ROOT_DIR, safePath),
        content,
        size: stat.size,
      });
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 3. Central AI Mainframe API using Google GenAI SDK
app.post("/api/ai", async (req, res) => {
  const { prompt, history } = req.body;
  if (!prompt) {
    return res.status(400).json({ error: "Prompt is required" });
  }

  if (!ai) {
    return res.json({
      reply: ">> ERROR: AI CORE OFFLINE. GEMINI_API_KEY is not configured in Secrets panel.\nPlease configure your API key in the Settings > Secrets menu."
    });
  }

  try {
    // Format conversation history for Gemini if present
    const contents: any[] = [];
    if (history && Array.isArray(history)) {
      history.forEach((msg: any) => {
        contents.push({
          role: msg.role === "assistant" ? "model" : "user",
          parts: [{ text: msg.content }]
        });
      });
    }
    
    // Add current prompt
    contents.push({
      role: "user",
      parts: [{ text: prompt }]
    });

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: contents,
      config: {
        systemInstruction: "You are the Cybernetic AI Core for eDEX-UI, a futuristic hacking computer mainframe console terminal. Give short, ultra-cool, immersive sci-fi terminal-like replies (maximum 2-3 paragraphs). Use hacker jargon, neon system brackets, or ASCII decoration where appropriate. Avoid friendly personal disclaimers unless they sound synthetic and computer-generated.",
        temperature: 0.8,
      },
    });

    res.json({ reply: response.text || ">> NO OUTPUT RECEIVED FROM CENTRAL MAIN FRAME CORE" });
  } catch (err: any) {
    console.error("AI Mainframe failure:", err);
    res.status(500).json({ error: `AI Command pipeline failure: ${err.message}` });
  }
});

// 4. Vite Dev Server Integration & Static Production build
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(ROOT_DIR, 'dist');
    app.use(express.static(distPath));
    // Serve index.html for all other routes (SPA fallback)
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[SYSINIT] eDEX-UI Host Core active on port ${PORT}`);
  });
}

startServer();
