export interface FileItem {
  name: string;
  path: string;
  isDirectory: boolean;
  size: number;
  mtime: string;
}

export interface ProcessItem {
  pid: number;
  name: string;
  cpu: number;
  mem: number;
  status: "RUNNING" | "SLEEPING" | "ZOMBIE" | "CRITICAL";
}

export interface TerminalLog {
  id: string;
  text: string;
  type: "input" | "system" | "error" | "output" | "ai";
}

export type ThemeType = "tron" | "matrix" | "amber" | "sanguine" | "chrome";

export interface ThemeColors {
  primary: string;       // main neon accent
  primaryGlow: string;   // glow shadow color
  bg: string;            // dark cyber background
  panelBg: string;       // translucent card background
  border: string;        // cyan/neon border
  text: string;          // main text
  textMuted: string;     // faded info
}

export const THEMES: Record<ThemeType, ThemeColors> = {
  tron: {
    primary: "rgb(6, 182, 212)", // cyan-500
    primaryGlow: "rgba(6, 182, 212, 0.4)",
    bg: "rgb(8, 15, 26)",
    panelBg: "rgba(11, 22, 34, 0.7)",
    border: "rgba(6, 182, 212, 0.3)",
    text: "rgb(204, 251, 241)", // teal-100
    textMuted: "rgb(103, 115, 128)"
  },
  matrix: {
    primary: "rgb(34, 197, 94)", // green-500
    primaryGlow: "rgba(34, 197, 94, 0.4)",
    bg: "rgb(4, 12, 6)",
    panelBg: "rgba(8, 20, 10, 0.75)",
    border: "rgba(34, 197, 94, 0.3)",
    text: "rgb(220, 252, 231)", // green-100
    textMuted: "rgb(74, 107, 78)"
  },
  amber: {
    primary: "rgb(245, 158, 11)", // amber-500
    primaryGlow: "rgba(245, 158, 11, 0.4)",
    bg: "rgb(15, 11, 5)",
    panelBg: "rgba(24, 18, 8, 0.75)",
    border: "rgba(245, 158, 11, 0.3)",
    text: "rgb(254, 243, 199)", // amber-100
    textMuted: "rgb(142, 110, 70)"
  },
  sanguine: {
    primary: "rgb(239, 68, 68)", // red-500
    primaryGlow: "rgba(239, 68, 68, 0.4)",
    bg: "rgb(18, 6, 6)",
    panelBg: "rgba(28, 10, 10, 0.75)",
    border: "rgba(239, 68, 68, 0.3)",
    text: "rgb(254, 226, 226)", // red-100
    textMuted: "rgb(150, 80, 80)"
  },
  chrome: {
    primary: "rgb(243, 244, 246)", // gray-100
    primaryGlow: "rgba(243, 244, 246, 0.3)",
    bg: "rgb(17, 24, 39)", // gray-900
    panelBg: "rgba(31, 41, 55, 0.75)",
    border: "rgba(243, 244, 246, 0.2)",
    text: "rgb(255, 255, 255)",
    textMuted: "rgb(156, 163, 175)"
  }
};
