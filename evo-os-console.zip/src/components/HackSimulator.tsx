import React, { useState, useEffect, useRef } from "react";
import { ThemeColors } from "../types";
import { sound } from "./SoundEngine";
import { 
  Play, 
  ShieldAlert, 
  CheckCircle2, 
  AlertOctagon, 
  Terminal, 
  Cpu, 
  Lock, 
  Unlock, 
  Activity, 
  RefreshCw, 
  Database,
  Hash,
  ShieldCheck,
  Zap
} from "lucide-react";

interface HackSimulatorProps {
  theme: ThemeColors;
  onSystemLog: (text: string, type: "system" | "error" | "output") => void;
}

type SubTab = "injector" | "cracker" | "network" | "hasher";

export default function HackSimulator({ theme, onSystemLog }: HackSimulatorProps) {
  const [activeTab, setActiveTab] = useState<SubTab>("injector");

  // =========================================================================
  // TOOL 1: EXPLOIT INJECTOR (EXISTING ENHANCED)
  // =========================================================================
  const [target, setTarget] = useState<string>("mainframe.gov.io");
  const [method, setMethod] = useState<string>("BUFFER_OVERFLOW");
  const [hacking, setHacking] = useState<boolean>(false);
  const [progress, setProgress] = useState<number>(0);
  const [logs, setLogs] = useState<string[]>([]);
  const [status, setStatus] = useState<"IDLE" | "HACKING" | "SUCCESS" | "FAULT">("IDLE");
  const [crackedKeys, setCrackedKeys] = useState<string[]>([]);
  const logContainerRef = useRef<HTMLDivElement>(null);

  const simulateLogs = [
    "Establishing proxy connection... TRACE ROUTE: 104.22.41.9",
    "Bypassing quantum-crypto handshake...",
    "Sending packet injection payload (32KB)...",
    "Firewall detected. Deploying cloaking algorithms...",
    "Testing memory block allocations for buffer exploit...",
    "Bypassing secure socket layer ports (TCP/443)...",
    "Cracking AES-256 block chains... [12% cracked]",
    "Brute force signature hash verification ongoing...",
    "Injecting root shell scripts... SUCCESS",
    "Acquiring administrative mainframe permissions...",
    "Downloading remote database schematics..."
  ];

  useEffect(() => {
    if (logContainerRef.current && activeTab === "injector") {
      logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
    }
  }, [logs, activeTab]);

  const handleStartHack = () => {
    if (hacking) return;
    
    sound.playAlarm();
    setHacking(true);
    setStatus("HACKING");
    setProgress(0);
    setCrackedKeys([]);
    setLogs(["[SYSINIT] Triggering Decrypter Core on target: " + target]);
    onSystemLog(`>> STARTING CYBER HACKING SEQUENCE ON: ${target}`, "system");

    let currentStep = 0;
    const interval = setInterval(() => {
      setProgress(prev => {
        const next = prev + Math.floor(Math.random() * 8) + 4;
        
        if (Math.random() > 0.5) {
          const hexKey = Array.from({ length: 8 }, () => Math.floor(Math.random() * 16).toString(16).toUpperCase()).join("");
          setCrackedKeys(k => [...k.slice(-4), `BLOCK_0x${hexKey}`]);
          sound.playClick(1.4);
        }

        if (next >= 100) {
          clearInterval(interval);
          setHacking(false);
          setStatus("SUCCESS");
          setLogs(l => [...l, "[COMPLETE] TARGET MAINFRAME HAS BEEN SUCCESSFULLY COMPROMISED."]);
          onSystemLog(`>> MAINFRAME DECRYPTION SUCCESSFUL ON ${target}! ROOT ACCESS PERMITTED.`, "system");
          sound.playBoot();
          return 100;
        }

        if (currentStep < simulateLogs.length && Math.random() > 0.5) {
          setLogs(l => [...l, `[OK] ${simulateLogs[currentStep]}`]);
          currentStep++;
        }

        return next;
      });
    }, 350);
  };

  // =========================================================================
  // TOOL 2: PASSWORD CRACKER & ENTROPY TESTER
  // =========================================================================
  const [password, setPassword] = useState<string>("admin123");
  const [crackProgress, setCrackProgress] = useState<number>(0);
  const [cracking, setCracking] = useState<boolean>(false);
  const [crackResult, setCrackResult] = useState<string>("");
  const [currentGuess, setCurrentGuess] = useState<string>("");

  const calculateEntropy = (pwd: string) => {
    if (!pwd) return { bits: 0, strength: "EMPTY", color: "text-gray-500" };
    let poolSize = 0;
    if (/[a-z]/.test(pwd)) poolSize += 26;
    if (/[A-Z]/.test(pwd)) poolSize += 26;
    if (/[0-9]/.test(pwd)) poolSize += 10;
    if (/[^a-zA-Z0-9]/.test(pwd)) poolSize += 33;

    const bits = Math.floor(pwd.length * Math.log2(poolSize || 1));
    if (bits < 25) return { bits, strength: "WEAK (EXPLOITABLE)", color: "text-red-500" };
    if (bits < 50) return { bits, strength: "MEDIUM (BRUTE-FORCEABLE)", color: "text-orange-400" };
    if (bits < 80) return { bits, strength: "STRONG (SECURE RESILIENCE)", color: "text-green-400" };
    return { bits, strength: "MILITARY COGNITIVE SPEC", color: "text-emerald-400 font-bold" };
  };

  const entropy = calculateEntropy(password);

  const startPasswordCrack = () => {
    if (!password || cracking) return;
    setCracking(true);
    setCrackProgress(0);
    setCrackResult("");
    sound.playStatic();
    onSystemLog(`>> INITIATING PASSWORD DICTIONARY CRACK ON ENTROPY CHAIN: ${password.length} Chars`, "system");

    const alphabet = "abcdefghijklmnopqrstuvwxyz0123456789!@#";
    let step = 0;
    const interval = setInterval(() => {
      setCrackProgress(prev => {
        const next = prev + Math.floor(Math.random() * 12) + 5;
        
        // Generate random scrambled guess text
        const guess = Array.from({ length: password.length }, (_, i) => {
          if (i < (password.length * next) / 100) return password[i];
          return alphabet[Math.floor(Math.random() * alphabet.length)];
        }).join("");
        setCurrentGuess(guess);
        sound.playClick(1.6);

        if (next >= 100) {
          clearInterval(interval);
          setCracking(false);
          setCrackResult(`PASSWORD CRACKED IN ${step * 40}ms! VALUE: [ ${password} ]`);
          setCurrentGuess(password);
          onSystemLog(`>> SUCCESS: PASSWORD '${password}' DEPICTED. DECRYPTION KEY FOUND.`, "output");
          sound.playLaser();
          return 100;
        }
        step++;
        return next;
      });
    }, 120);
  };

  // =========================================================================
  // TOOL 3: NETWORK PORT VULNERABILITY SCANNER
  // =========================================================================
  const [ipAddress, setIpAddress] = useState<string>("192.168.1.104");
  const [scanning, setScanning] = useState<boolean>(false);
  const [scanProgress, setScanProgress] = useState<number>(0);
  const [scanPorts, setScanPorts] = useState<Array<{ port: number; svc: string; state: "CLOSED" | "OPEN" | "VULNERABLE" | "PATCHED"; cve?: string }>>([
    { port: 21, svc: "FTP (Vsftpd 2.3.4)", state: "CLOSED" },
    { port: 22, svc: "SSH (OpenSSH 7.2p2)", state: "CLOSED" },
    { port: 80, svc: "HTTP (Apache 2.4.18)", state: "CLOSED" },
    { port: 443, svc: "HTTPS (OpenSSL)", state: "CLOSED" },
    { port: 3306, svc: "MySQL (Oracle 5.5)", state: "CLOSED" },
    { port: 8080, svc: "TCP (Node.js Dev Server)", state: "CLOSED" },
  ]);

  const handleStartScan = () => {
    if (scanning) return;
    setScanning(true);
    setScanProgress(0);
    // Reset states to closed
    setScanPorts(ports => ports.map(p => ({ ...p, state: "CLOSED" })));
    sound.playPulse();
    onSystemLog(`>> SPARKING NETWORK PORT SCAN VECTOR ON HOST IP: ${ipAddress}`, "system");

    const vulnerabilityMap: Record<number, { state: "CLOSED" | "OPEN" | "VULNERABLE" | "PATCHED"; cve?: string }> = {
      21: { state: "VULNERABLE", cve: "CVE-2011-2523" },
      22: { state: "OPEN" },
      80: { state: "OPEN" },
      443: { state: "OPEN" },
      3306: { state: "VULNERABLE", cve: "CVE-2012-2122" },
      8080: { state: "OPEN" }
    };

    let idx = 0;
    const interval = setInterval(() => {
      if (idx < scanPorts.length) {
        setScanPorts(ports => {
          const updated = [...ports];
          const targetPort = updated[idx];
          const resolution = vulnerabilityMap[targetPort.port] || { state: "CLOSED" as const, cve: undefined };
          updated[idx] = { ...targetPort, state: resolution.state, cve: resolution.cve };
          return updated;
        });
        sound.playClick(1.2);
        idx++;
        setScanProgress(Math.floor((idx / scanPorts.length) * 100));
      } else {
        clearInterval(interval);
        setScanning(false);
        onSystemLog(`>> NET AUDIT COMPLETED ON ${ipAddress}. VULNERABILITIES FLAGGED.`, "output");
        sound.playAlarm();
      }
    }, 400);
  };

  const handlePatchVulnerability = (portNum: number) => {
    setScanPorts(ports => ports.map(p => {
      if (p.port === portNum) {
        onSystemLog(`>> INJECTED EVO-DEFENSE SECURE FIREWALL PATCH ON PORT ${portNum}`, "system");
        sound.playBoot();
        return { ...p, state: "PATCHED" };
      }
      return p;
    }));
  };

  // =========================================================================
  // TOOL 4: CRYPTOGRAPHIC HASH ENCODER
  // =========================================================================
  const [plainText, setPlainText] = useState<string>("EricLM");
  const [hashes, setHashes] = useState({
    md5: "FA7A33B8E1D94C0FA7A33B8E1D94C0FF",
    sha256: "8A23C2A9B3E5C8D00F98E8D092E1B4F4A23C2A9B3E5C8D00F98E8D092E1B4F4A",
    base64: "RXJpY0xN",
    binary: "01000101 01110010 01101001 01100011 01001100 01001101"
  });

  useEffect(() => {
    if (activeTab === "hasher") {
      // Simple custom crypto hash simulations based on character inputs
      let h1 = 0x811c9dc5;
      let h2 = 0x55555555;
      for (let i = 0; i < plainText.length; i++) {
        const char = plainText.charCodeAt(i);
        h1 ^= char;
        h1 += (h1 << 1) + (h1 << 4) + (h1 << 7) + (h1 << 8) + (h1 << 24);
        h2 = (h2 << 5) - h2 + char;
      }
      const hex1 = (h1 >>> 0).toString(16).toUpperCase().padStart(8, "0");
      const hex2 = (Math.abs(h2) >>> 0).toString(16).toUpperCase().padStart(8, "0");
      const md5Sim = `${hex1}${hex2}F1A8C3D29`.slice(0, 32);
      const sha256Sim = `${hex1}8C4E9D${hex2}A1D2D3E4F5A6B7C8D9E0F1A2B3C4D5E6F7`.slice(0, 64);
      const b64Sim = btoa(plainText || " ").slice(0, 24);
      
      const binSim = plainText.split("")
        .map(c => c.charCodeAt(0).toString(2).padStart(8, "0"))
        .join(" ");

      setHashes({
        md5: md5Sim,
        sha256: sha256Sim,
        base64: b64Sim,
        binary: binSim || "[NULL]"
      });
    }
  }, [plainText, activeTab]);


  return (
    <div className="h-full flex flex-col justify-between font-mono p-3 space-y-3">
      {/* Title Header */}
      <div className="border-b pb-1.5 flex justify-between items-center" style={{ borderColor: theme.border }}>
        <div className="flex items-center space-x-2">
          <ShieldAlert size={14} className="animate-pulse text-green-400" />
          <span className="text-[10px] uppercase font-bold tracking-widest text-green-400">
            // EVO COGNITIVE HACKING SUITE
          </span>
        </div>
        <span className="text-[8px] opacity-50 font-mono">SECURE CONTEXT</span>
      </div>

      {/* Cyber Tab Controller */}
      <div className="grid grid-cols-4 gap-1 p-0.5 bg-black/40 border rounded text-[8px] font-bold" style={{ borderColor: theme.border }}>
        {[
          { key: "injector", label: "EXPLOITS" },
          { key: "cracker", label: "PWD CRACK" },
          { key: "network", label: "NET SCAN" },
          { key: "hasher", label: "CRYPTO" },
        ].map(t => (
          <button
            key={t.key}
            onClick={() => {
              sound.playClick(1.1);
              setActiveTab(t.key as SubTab);
            }}
            className={`py-1 text-center rounded-sm uppercase transition-all cursor-pointer ${
              activeTab === t.key 
                ? "bg-green-500/25 text-green-400 border border-green-500/40 shadow-[0_0_8px_rgba(34,197,94,0.2)]" 
                : "text-gray-400 hover:text-white"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Dynamic Tab Workspace */}
      <div className="flex-1 min-h-0">
        
        {/* TAB 1: EXPLOIT INJECTOR */}
        {activeTab === "injector" && (
          <div className="h-full flex flex-col justify-between space-y-2">
            <div className="grid grid-cols-2 gap-2 text-[9px]">
              <div className="space-y-0.5">
                <span className="opacity-60 text-[8px]" style={{ color: theme.text }}>TARGET COGNITIVE HOST</span>
                <input 
                  type="text" 
                  value={target}
                  disabled={hacking}
                  onChange={(e) => setTarget(e.target.value)}
                  className="w-full bg-black/50 border rounded px-2 py-0.5 text-white text-[10px] outline-none focus:border-green-500 transition-colors"
                  style={{ borderColor: theme.border }}
                />
              </div>
              <div className="space-y-0.5">
                <span className="opacity-60 text-[8px]" style={{ color: theme.text }}>VECTORS</span>
                <select 
                  value={method}
                  disabled={hacking}
                  onChange={(e) => setMethod(e.target.value)}
                  className="w-full bg-black/70 border rounded px-1 py-0.5 text-white text-[10px] outline-none"
                  style={{ borderColor: theme.border }}
                >
                  <option value="BUFFER_OVERFLOW">BUFFER OVERFLOW</option>
                  <option value="DDOS_FLOOD">SYN PORT FLOOD</option>
                  <option value="SQL_INJECTION">SQL SCHEMA EXTRACT</option>
                  <option value="XERO_BYPASS">NEURAL BYPASS</option>
                </select>
              </div>
            </div>

            <div className="flex-1 min-h-0 grid grid-cols-12 gap-1.5 py-1">
              <div 
                ref={logContainerRef}
                className="col-span-8 border bg-black/40 rounded p-1.5 overflow-y-auto text-[9px] space-y-1 select-text scrollbar-thin"
                style={{ borderColor: theme.border }}
              >
                {logs.length === 0 ? (
                  <div className="h-full flex items-center justify-center opacity-40 text-center text-[8px]">
                    [READY FOR EXPLOIT RUN]
                  </div>
                ) : (
                  logs.map((log, i) => (
                    <div key={i} className="text-white tracking-tight leading-tight whitespace-pre-wrap font-mono text-[8.5px]">
                      <span className="text-green-500 mr-1">&gt;</span>
                      {log}
                    </div>
                  ))
                )}
              </div>

              <div className="col-span-4 border bg-black/60 rounded p-1.5 flex flex-col justify-between text-[8px]" style={{ borderColor: theme.border }}>
                <div className="font-bold border-b pb-1 text-center text-green-400">HEX CHAINS</div>
                <div className="flex-1 space-y-1 flex flex-col justify-center select-all">
                  {crackedKeys.length === 0 ? (
                    <span className="text-center opacity-40">[EMPTY MATRIX]</span>
                  ) : (
                    crackedKeys.map((k, i) => (
                      <div key={i} className="text-green-400 font-mono text-[7px] bg-green-950/20 px-1 py-0.5 rounded text-center border border-green-500/20">
                        {k}
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>

            <div className="space-y-1.5">
              {hacking && (
                <div className="space-y-0.5">
                  <div className="flex justify-between text-[8px] font-bold text-green-400">
                    <span>INJECTING PAYLOAD EXPLORATION...</span>
                    <span>{progress}%</span>
                  </div>
                  <div className="h-1.5 w-full bg-black/60 border rounded overflow-hidden" style={{ borderColor: theme.border }}>
                    <div 
                      className="h-full bg-green-500 transition-all duration-300"
                      style={{ 
                        width: `${progress}%`,
                        boxShadow: `0 0 8px rgba(34,197,94,0.6)`
                      }}
                    />
                  </div>
                </div>
              )}

              <button
                onClick={handleStartHack}
                disabled={hacking}
                className="w-full py-1.5 rounded font-bold tracking-wider text-[10px] uppercase transition-all duration-200 border cursor-pointer hover:bg-white/5 text-green-400 flex items-center justify-center space-x-1.5"
                style={{ borderColor: status === "SUCCESS" ? "rgba(34,197,94,0.4)" : theme.border }}
              >
                {status === "SUCCESS" ? (
                  <>
                    <CheckCircle2 size={11} className="text-green-400" />
                    <span>SYS SECURED / RESTART VECTOR</span>
                  </>
                ) : (
                  <>
                    <Play size={10} />
                    <span>LAUNCH COGNITIVE INJECTOR</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}

        {/* TAB 2: PASSWORD CRACKER */}
        {activeTab === "cracker" && (
          <div className="h-full flex flex-col justify-between space-y-2 text-[9px]">
            <div className="space-y-1">
              <span className="opacity-60 text-[8px]">TARGET TEST PASSWORD</span>
              <div className="flex space-x-1">
                <input 
                  type="text" 
                  value={password}
                  disabled={cracking}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter custom password..."
                  className="flex-1 bg-black/50 border rounded px-2 py-1 text-white text-[10px] outline-none focus:border-green-500"
                  style={{ borderColor: theme.border }}
                />
              </div>
            </div>

            {/* Password Entropy Analysis Card */}
            <div className="border bg-black/50 rounded p-2 space-y-1" style={{ borderColor: theme.border }}>
              <div className="flex justify-between">
                <span className="opacity-60">PASSWORD LENGTH:</span>
                <span className="text-white font-bold">{password.length} characters</span>
              </div>
              <div className="flex justify-between">
                <span className="opacity-60">ENTROPY RATING:</span>
                <span className="text-white font-bold">{entropy.bits} BITS</span>
              </div>
              <div className="flex justify-between">
                <span className="opacity-60">STRENGTH GRADE:</span>
                <span className={entropy.color}>{entropy.strength}</span>
              </div>
            </div>

            {/* Crack progress display */}
            <div className="border bg-black/40 rounded p-2 flex flex-col justify-center items-center h-16 relative overflow-hidden" style={{ borderColor: theme.border }}>
              {cracking ? (
                <div className="text-center space-y-1 z-10 w-full">
                  <div className="text-[10px] font-mono text-green-400 tracking-widest uppercase font-black animate-pulse">
                    GUESSING: {currentGuess}
                  </div>
                  <div className="text-[8px] opacity-60">DICTIONARY ATTEMPTS ONGOING: {crackProgress}%</div>
                  <div className="w-full bg-black/60 h-1 border rounded overflow-hidden" style={{ borderColor: theme.border }}>
                    <div className="bg-green-500 h-full transition-all" style={{ width: `${crackProgress}%` }}></div>
                  </div>
                </div>
              ) : crackResult ? (
                <div className="text-center text-green-400 font-bold z-10 p-1">
                  <Unlock size={14} className="mx-auto mb-1 text-green-400 animate-bounce" />
                  <div>{crackResult}</div>
                </div>
              ) : (
                <div className="text-center opacity-40 z-10">
                  <Lock size={12} className="mx-auto mb-1 text-green-400" />
                  <span>[DICT-CRACK SYSTEM READY FOR COUPLING]</span>
                </div>
              )}
            </div>

            <button
              onClick={startPasswordCrack}
              disabled={cracking || !password}
              className="w-full py-1.5 rounded font-bold tracking-wider text-[10px] uppercase transition-all duration-200 border cursor-pointer hover:bg-white/5 text-green-400 flex items-center justify-center space-x-1"
              style={{ borderColor: theme.border }}
            >
              <RefreshCw size={11} className={cracking ? "animate-spin text-green-400" : "text-green-400"} />
              <span>{cracking ? "CRACKING COGNITIVE KEYS..." : "SIMULATE EXPLOIT CRACK"}</span>
            </button>
          </div>
        )}

        {/* TAB 3: NETWORK PORT SCANNER */}
        {activeTab === "network" && (
          <div className="h-full flex flex-col justify-between space-y-2 text-[9px]">
            <div className="grid grid-cols-12 gap-1">
              <div className="col-span-8">
                <input 
                  type="text" 
                  value={ipAddress}
                  disabled={scanning}
                  onChange={(e) => setIpAddress(e.target.value)}
                  className="w-full bg-black/50 border rounded px-2 py-0.5 text-white text-[10px] outline-none focus:border-green-500"
                  style={{ borderColor: theme.border }}
                />
              </div>
              <button
                onClick={handleStartScan}
                disabled={scanning}
                className="col-span-4 bg-green-500/20 border border-green-500/40 text-green-400 font-bold rounded hover:bg-green-500/40 transition-all text-[8px] cursor-pointer py-1"
              >
                {scanning ? "SCANNING..." : "NET AUDIT"}
              </button>
            </div>

            {/* List of Scanned Ports */}
            <div className="flex-1 min-h-0 border bg-black/40 rounded p-1.5 overflow-y-auto space-y-1.5 select-none scrollbar-thin" style={{ borderColor: theme.border }}>
              {scanPorts.map((p) => (
                <div key={p.port} className="flex justify-between items-center text-[8.5px] border-b border-white/5 pb-1 last:border-0">
                  <div className="flex items-center space-x-1.5">
                    <span className="text-green-500 font-bold">:{p.port}</span>
                    <span className="text-white opacity-70 truncate max-w-[120px]">{p.svc}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    {p.state === "CLOSED" ? (
                      <span className="text-gray-500 uppercase">CLOSED</span>
                    ) : p.state === "OPEN" ? (
                      <span className="text-green-400 font-bold uppercase">OPEN</span>
                    ) : p.state === "VULNERABLE" ? (
                      <div className="flex items-center space-x-1">
                        <span className="text-red-500 font-bold animate-pulse uppercase">VULN ({p.cve})</span>
                        <button 
                          onClick={() => handlePatchVulnerability(p.port)}
                          className="px-1 py-0.5 bg-red-950/40 border border-red-500/30 hover:bg-green-500 hover:text-black rounded text-[6.5px] transition-all font-bold cursor-pointer"
                        >
                          PATCH
                        </button>
                      </div>
                    ) : (
                      <span className="text-emerald-400 font-bold uppercase flex items-center space-x-0.5">
                        <ShieldCheck size={8} />
                        <span>PATCHED</span>
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Simulated connection status */}
            <div className="flex justify-between text-[7.5px] opacity-50 px-1">
              <span>SCANNER LATENCY: ~14ms</span>
              <span>FIREWALL INTRUSION: SUCCESS</span>
            </div>
          </div>
        )}

        {/* TAB 4: HASH ENCODER */}
        {activeTab === "hasher" && (
          <div className="h-full flex flex-col justify-between space-y-2 text-[9px]">
            <div className="space-y-1">
              <span className="opacity-60 text-[8px]">INPUT TEXT TO CONVERT</span>
              <input 
                type="text" 
                value={plainText}
                onChange={(e) => setPlainText(e.target.value)}
                placeholder="Type word to hash..."
                className="w-full bg-black/50 border rounded px-2 py-0.5 text-white text-[10px] outline-none focus:border-green-500"
                style={{ borderColor: theme.border }}
              />
            </div>

            {/* Generated hashes visual stack */}
            <div className="flex-1 min-h-0 border bg-black/40 rounded p-1.5 overflow-y-auto space-y-2 font-mono scrollbar-thin" style={{ borderColor: theme.border }}>
              <div className="space-y-0.5">
                <div className="flex justify-between text-[7px] text-green-500">
                  <span>MD5 SIGNATURE EMULATION:</span>
                  <span className="opacity-50">32-HEX</span>
                </div>
                <div className="bg-black/60 px-1 py-0.5 rounded border border-white/5 text-white select-all text-[7.5px] break-all leading-none py-1">
                  {hashes.md5}
                </div>
              </div>

              <div className="space-y-0.5">
                <div className="flex justify-between text-[7px] text-green-500">
                  <span>SHA-256 SECURE COGNITIVE HASH:</span>
                  <span className="opacity-50">64-HEX</span>
                </div>
                <div className="bg-black/60 px-1 py-0.5 rounded border border-white/5 text-white select-all text-[7.5px] break-all leading-none py-1">
                  {hashes.sha256}
                </div>
              </div>

              <div className="space-y-0.5">
                <div className="flex justify-between text-[7px] text-green-500">
                  <span>BASE64 CIPHER STREAM:</span>
                  <span className="opacity-50">ASCII-STREAM</span>
                </div>
                <div className="bg-black/60 px-1 py-0.5 rounded border border-white/5 text-white select-all text-[7.5px] break-all leading-none py-1">
                  {hashes.base64}
                </div>
              </div>

              <div className="space-y-0.5">
                <div className="flex justify-between text-[7px] text-green-500">
                  <span>BINARY RAW SEQUENCE:</span>
                  <span className="opacity-50">8-BIT CHUNKS</span>
                </div>
                <div className="bg-black/60 px-1 py-0.5 rounded border border-white/5 text-emerald-400 select-all text-[6.5px] leading-tight py-1 max-h-[26px] overflow-y-auto">
                  {hashes.binary}
                </div>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
