import { useEffect, useState } from "react";
import { Folder, File, ChevronLeft, HardDrive, RefreshCw } from "lucide-react";
import { ThemeColors, FileItem } from "../types";
import { sound } from "./SoundEngine";

interface FileExplorerProps {
  theme: ThemeColors;
  onOpenFileInTerminal: (filePath: string) => void;
}

export default function FileExplorer({ theme, onOpenFileInTerminal }: FileExplorerProps) {
  const [currentPath, setCurrentPath] = useState<string>(".");
  const [items, setItems] = useState<FileItem[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const loadDirectory = async (targetPath: string) => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/files", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ path: targetPath }),
      });

      if (!res.ok) {
        throw new Error(`Terminal responded with code ${res.status}`);
      }

      const data = await res.json();
      if (data.isDirectory) {
        setItems(data.items);
        setCurrentPath(data.currentPath);
      }
    } catch (err: any) {
      setError(err.message || "Failed to load directory");
      sound.playError();
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDirectory(".");
  }, []);

  const handleItemClick = (item: FileItem) => {
    sound.playClick(1.1);
    if (item.isDirectory) {
      loadDirectory(item.path);
    } else {
      // Open file content in terminal callback
      onOpenFileInTerminal(item.path);
    }
  };

  const handleNavigateUp = () => {
    sound.playClick(0.9);
    if (currentPath === "." || currentPath === "") return;
    const parts = currentPath.split("/");
    parts.pop();
    const parent = parts.join("/") || ".";
    loadDirectory(parent);
  };

  const handleRefresh = () => {
    sound.playClick(1.0);
    loadDirectory(currentPath);
  };

  const formatSize = (bytes: number) => {
    if (bytes === 0) return "0 B";
    const k = 1024;
    const dm = 1;
    const sizes = ["B", "KB", "MB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + " " + sizes[i];
  };

  return (
    <div className="h-full flex flex-col font-mono p-4 space-y-3 justify-between">
      {/* Header */}
      <div className="border-b pb-2 flex justify-between items-center" style={{ borderColor: theme.border }}>
        <div className="flex items-center space-x-2">
          <HardDrive size={14} style={{ color: theme.primary }} />
          <span className="text-xs uppercase font-bold tracking-widest" style={{ color: theme.primary }}>
            // FILE SYSTEM NAVIGATOR
          </span>
        </div>
        <button 
          onClick={handleRefresh}
          className="p-1 rounded opacity-75 hover:opacity-100 transition-opacity hover:bg-white/10"
          title="Refresh FS"
        >
          <RefreshCw size={12} style={{ color: theme.primary }} />
        </button>
      </div>

      {/* Path bar */}
      <div className="flex items-center space-x-2 text-[11px] bg-black/40 border p-1.5 rounded select-none truncate" style={{ borderColor: theme.border, color: theme.text }}>
        <span className="opacity-50">PATH:</span>
        <span className="font-bold tracking-tight text-white">{currentPath || "/"}</span>
      </div>

      {/* List Container */}
      <div className="flex-1 min-h-0 overflow-y-auto border bg-black/25 rounded p-1 space-y-1" style={{ borderColor: theme.border }}>
        {loading ? (
          <div className="h-full flex items-center justify-center">
            <span className="text-xs animate-pulse" style={{ color: theme.primary }}>[QUERYING FILESYSTEM RECURSION...]</span>
          </div>
        ) : error ? (
          <div className="p-3 text-xs text-red-400">
            &gt;&gt; FAULT: {error}
          </div>
        ) : (
          <div className="space-y-[2px]">
            {/* Parent folder connector '..' */}
            {currentPath !== "." && currentPath !== "" && (
              <div 
                onClick={handleNavigateUp}
                className="flex items-center space-x-2 p-1.5 rounded cursor-pointer hover:bg-white/5 transition-all text-xs opacity-80 hover:opacity-100"
              >
                <ChevronLeft size={14} style={{ color: theme.primary }} />
                <span style={{ color: theme.text }}>.. (Parent directory)</span>
              </div>
            )}

            {items.length === 0 ? (
              <div className="p-4 text-center text-xs opacity-50" style={{ color: theme.text }}>
                [DIRECTORY IS EMPTY]
              </div>
            ) : (
              items.map((item, index) => (
                <div 
                  key={index}
                  onClick={() => handleItemClick(item)}
                  className="flex items-center justify-between p-1.5 rounded cursor-pointer transition-all hover:bg-white/5 text-[11px]"
                >
                  <div className="flex items-center space-x-2 min-w-0 pr-2">
                    {item.isDirectory ? (
                      <Folder size={13} className="shrink-0" style={{ color: theme.primary }} />
                    ) : (
                      <File size={13} className="shrink-0" style={{ color: theme.textMuted }} />
                    )}
                    <span className="truncate text-white hover:underline">
                      {item.name}
                    </span>
                  </div>
                  <span className="text-[9px] opacity-65 shrink-0" style={{ color: theme.textMuted }}>
                    {item.isDirectory ? "[DIR]" : formatSize(item.size)}
                  </span>
                </div>
              ))
            )}
          </div>
        )}
      </div>

      {/* Footer hint */}
      <div className="text-[9px] opacity-50 select-none flex justify-between" style={{ color: theme.text }}>
        <span>CLICK FOLDER TO OPEN</span>
        <span>CLICK FILE TO TERMINAL CAT</span>
      </div>
    </div>
  );
}
