import React, { useEffect, useState } from "react";
import { Activity, XCircle, Play, Info } from "lucide-react";
import { ThemeColors, ProcessItem } from "../types";
import { sound } from "./SoundEngine";

interface ProcessManagerProps {
  theme: ThemeColors;
}

const INITIAL_PROCESSES: ProcessItem[] = [
  { pid: 104, name: "node server.ts", cpu: 1.2, mem: 48.5, status: "RUNNING" },
  { pid: 215, name: "vite-bundler", cpu: 0.1, mem: 124.2, status: "SLEEPING" },
  { pid: 312, name: "nginx-ingress", cpu: 0.4, mem: 18.1, status: "RUNNING" },
  { pid: 489, name: "gemini-api-core", cpu: 0.0, mem: 32.7, status: "SLEEPING" },
  { pid: 502, name: "sound-synthesizer", cpu: 1.5, mem: 12.0, status: "RUNNING" },
  { pid: 611, name: "matrix-rain-rain", cpu: 2.8, mem: 8.5, status: "RUNNING" },
  { pid: 720, name: "sys-telemetry", cpu: 0.8, mem: 16.4, status: "RUNNING" },
];

export default function ProcessManager({ theme }: ProcessManagerProps) {
  const [processes, setProcesses] = useState<ProcessItem[]>(INITIAL_PROCESSES);
  const [selectedPid, setSelectedPid] = useState<number | null>(104);
  const [newProcName, setNewProcName] = useState<string>("");

  // Periodically fluctuate CPU and MEM for cybernetic realism
  useEffect(() => {
    const interval = setInterval(() => {
      setProcesses(prev => 
        prev.map(p => {
          if (p.status === "RUNNING") {
            const cpuDelta = (Math.random() - 0.5) * 1.5;
            const memDelta = (Math.random() - 0.5) * 0.4;
            return {
              ...p,
              cpu: Math.max(0.1, parseFloat((p.cpu + cpuDelta).toFixed(1))),
              mem: Math.max(5.0, parseFloat((p.mem + memDelta).toFixed(1))),
            };
          }
          return p;
        })
      );
    }, 1200);

    return () => clearInterval(interval);
  }, []);

  const handleSelectProcess = (p: ProcessItem) => {
    sound.playClick(1.0);
    setSelectedPid(p.pid);
  };

  const handleKillProcess = (pid: number) => {
    sound.playError();
    setProcesses(prev => 
      prev.map(p => {
        if (p.pid === pid) {
          return { ...p, cpu: 0.0, status: "ZOMBIE" };
        }
        return p;
      })
    );

    // Auto-restart killed process after 4 seconds to simulate server self-healing
    setTimeout(() => {
      setProcesses(prev =>
        prev.map(p => {
          if (p.pid === pid) {
            return { 
              ...p, 
              status: "RUNNING", 
              cpu: parseFloat((Math.random() * 2 + 0.5).toFixed(1)) 
            };
          }
          return p;
        })
      );
    }, 4000);
  };

  const handleSpawnProcess = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProcName.trim()) return;
    
    sound.playBeep();
    const newPid = Math.floor(Math.random() * 800) + 200;
    const newProc: ProcessItem = {
      pid: newPid,
      name: newProcName.trim().toLowerCase(),
      cpu: parseFloat((Math.random() * 4 + 1.0).toFixed(1)),
      mem: parseFloat((Math.random() * 30 + 10).toFixed(1)),
      status: "RUNNING"
    };

    setProcesses(prev => [...prev, newProc]);
    setSelectedPid(newPid);
    setNewProcName("");
  };

  const selectedProcess = processes.find(p => p.pid === selectedPid);

  return (
    <div className="h-full flex flex-col font-mono p-4 space-y-3 justify-between">
      {/* Header */}
      <div className="border-b pb-2 flex justify-between items-center" style={{ borderColor: theme.border }}>
        <div className="flex items-center space-x-2">
          <Activity size={14} style={{ color: theme.primary }} />
          <span className="text-xs uppercase font-bold tracking-widest" style={{ color: theme.primary }}>
            // COGNITIVE PROCESS CONTROLLER
          </span>
        </div>
        <span className="text-[9px] opacity-75" style={{ color: theme.primary }}>
          ACTIVE: {processes.filter(p => p.status === "RUNNING").length}
        </span>
      </div>

      {/* Main split display: Left list, Right inspector */}
      <div className="flex-1 min-h-0 grid grid-cols-12 gap-3">
        {/* Left List of Processes */}
        <div className="col-span-7 flex flex-col border rounded bg-black/20 overflow-hidden" style={{ borderColor: theme.border }}>
          {/* Table Header */}
          <div className="grid grid-cols-12 gap-1 text-[9px] uppercase border-b p-1 bg-black/40 font-bold" style={{ borderColor: theme.border, color: theme.primary }}>
            <span className="col-span-3">PID</span>
            <span className="col-span-5">PROCESS</span>
            <span className="col-span-2 text-right">CPU</span>
            <span className="col-span-2 text-right">MEM</span>
          </div>

          {/* Table Body */}
          <div className="flex-1 overflow-y-auto space-y-[2px] p-1">
            {processes.map((p) => (
              <div
                key={p.pid}
                onClick={() => handleSelectProcess(p)}
                className="grid grid-cols-12 gap-1 text-[10px] p-1 rounded cursor-pointer transition-all hover:bg-white/5 items-center"
                style={{
                  backgroundColor: selectedPid === p.pid ? "rgba(255,255,255,0.06)" : "transparent",
                  color: p.status === "ZOMBIE" ? "rgb(239, 68, 68)" : theme.text
                }}
              >
                <span className="col-span-3 font-semibold opacity-70">#{p.pid}</span>
                <span className="col-span-5 truncate text-white">{p.name}</span>
                <span className="col-span-2 text-right text-emerald-400 font-bold">{p.cpu}%</span>
                <span className="col-span-2 text-right opacity-80">{p.mem}M</span>
              </div>
            ))}
          </div>
        </div>

        {/* Right Inspector & Control Panel */}
        <div className="col-span-5 flex flex-col justify-between border rounded p-2 bg-black/30 text-[10px]" style={{ borderColor: theme.border }}>
          {selectedProcess ? (
            <div className="space-y-2 flex-1 flex flex-col justify-between">
              {/* Process Stats */}
              <div className="space-y-1">
                <div className="font-bold border-b pb-1 flex items-center space-x-1" style={{ borderColor: theme.border, color: theme.primary }}>
                  <Info size={11} />
                  <span className="truncate">INSPECTING #{selectedProcess.pid}</span>
                </div>
                <div className="pt-1 text-white uppercase font-semibold text-xs truncate">
                  {selectedProcess.name}
                </div>
                <div className="flex justify-between opacity-80 pt-1">
                  <span>STATE:</span>
                  <span className={selectedProcess.status === "ZOMBIE" ? "text-red-500 font-bold" : "text-emerald-400 font-bold"}>
                    {selectedProcess.status}
                  </span>
                </div>
                <div className="flex justify-between opacity-80">
                  <span>PARENT PID:</span>
                  <span className="text-white">1</span>
                </div>
                <div className="flex justify-between opacity-80">
                  <span>ALLOCATED MEM:</span>
                  <span className="text-white">{selectedProcess.mem} MB</span>
                </div>
              </div>

              {/* Action buttons */}
              <div className="pt-2">
                {selectedProcess.status !== "ZOMBIE" ? (
                  <button
                    onClick={() => handleKillProcess(selectedProcess.pid)}
                    className="w-full py-1.5 rounded font-bold border transition-all text-red-100 hover:text-white flex items-center justify-center space-x-1 cursor-pointer bg-red-950/40 hover:bg-red-900/60"
                    style={{ borderColor: "rgba(239, 68, 68, 0.4)" }}
                  >
                    <XCircle size={12} />
                    <span>SIGKILL TERMINATE</span>
                  </button>
                ) : (
                  <div className="text-center text-[9px] text-red-500 py-1 border border-dashed border-red-500/30 animate-pulse bg-red-950/10">
                    REBOOT SECURE FAULT SHIELD...
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="h-full flex items-center justify-center text-center opacity-40">
              [NO PID SELECTED]
            </div>
          )}
        </div>
      </div>

      {/* New process simulator form */}
      <form onSubmit={handleSpawnProcess} className="flex space-x-1 text-[11px]" style={{ borderColor: theme.border }}>
        <input
          type="text"
          value={newProcName}
          onChange={(e) => setNewProcName(e.target.value)}
          placeholder="spawn custom process_cmd..."
          className="flex-1 bg-black/60 border rounded px-2 py-1 outline-none text-white focus:border-white transition-colors"
          style={{ borderColor: theme.border }}
        />
        <button
          type="submit"
          className="border rounded px-3 py-1 cursor-pointer transition-all hover:bg-white/10"
          style={{ borderColor: theme.border, color: theme.primary }}
        >
          <Play size={10} className="inline mr-1" />
          SPAWN
        </button>
      </form>
    </div>
  );
}
