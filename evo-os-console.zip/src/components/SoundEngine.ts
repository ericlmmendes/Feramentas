// Dynamic Synthesized Web Audio Engine for Cybernetic HUD Interface
class SoundEngine {
  private ctx: AudioContext | null = null;
  private humOsc: OscillatorNode | null = null;
  private humGain: GainNode | null = null;
  private isHumming: boolean = false;
  private volume: number = 0.4; // global scaling

  private init() {
    if (this.ctx) return;
    try {
      this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    } catch (e) {
      console.warn("Web Audio API not supported in this environment.", e);
    }
  }

  setVolume(vol: number) {
    this.volume = Math.max(0, Math.min(1, vol));
    if (this.humGain && this.isHumming) {
      this.humGain.gain.setValueAtTime(this.volume * 0.04, this.ctx?.currentTime || 0);
    }
  }

  getVolume() {
    return this.volume;
  }

  playClick(pitch: number = 1.0) {
    this.init();
    if (!this.ctx || this.volume === 0) return;

    const t = this.ctx.currentTime;
    
    // Quick noise impulse + high sine tick for a modern metallic click
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = "sine";
    osc.frequency.setValueAtTime(2200 * pitch, t);
    osc.frequency.exponentialRampToValueAtTime(800 * pitch, t + 0.04);

    gain.gain.setValueAtTime(this.volume * 0.15, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + 0.04);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(t);
    osc.stop(t + 0.05);
  }

  playBeep() {
    this.init();
    if (!this.ctx || this.volume === 0) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = "triangle";
    osc.frequency.setValueAtTime(1200, t);
    osc.frequency.setValueAtTime(1600, t + 0.06);

    gain.gain.setValueAtTime(this.volume * 0.1, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.15);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(t);
    osc.stop(t + 0.16);
  }

  playError() {
    this.init();
    if (!this.ctx || this.volume === 0) return;

    const t = this.ctx.currentTime;
    const osc1 = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc1.type = "sawtooth";
    osc2.type = "sine";
    
    osc1.frequency.setValueAtTime(120, t);
    osc2.frequency.setValueAtTime(124, t); // beat frequency for dread effect

    gain.gain.setValueAtTime(this.volume * 0.2, t);
    gain.gain.linearRampToValueAtTime(0.01, t + 0.3);

    osc1.connect(gain);
    osc2.connect(gain);
    gain.connect(this.ctx.destination);

    osc1.start(t);
    osc2.start(t);
    
    osc1.stop(t + 0.32);
    osc2.stop(t + 0.32);
  }

  playBoot() {
    this.init();
    if (!this.ctx || this.volume === 0) return;

    const t = this.ctx.currentTime;
    const frequencies = [261.63, 329.63, 392.00, 523.25, 659.25, 783.99, 1046.50]; // C major arpeggio
    
    frequencies.forEach((freq, index) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      
      osc.type = "sine";
      osc.frequency.setValueAtTime(freq, t + index * 0.06);
      osc.frequency.exponentialRampToValueAtTime(freq * 1.5, t + index * 0.06 + 0.4);
      
      gain.gain.setValueAtTime(0, t);
      gain.gain.linearRampToValueAtTime(this.volume * 0.04, t + index * 0.06);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + index * 0.06 + 0.6);
      
      osc.connect(gain);
      gain.connect(this.ctx!.destination);
      
      osc.start(t + index * 0.06);
      osc.stop(t + index * 0.06 + 0.65);
    });
  }

  toggleHum(active: boolean) {
    this.init();
    if (!this.ctx) return;

    if (active && !this.isHumming && this.volume > 0) {
      try {
        const t = this.ctx.currentTime;
        this.humOsc = this.ctx.createOscillator();
        this.humGain = this.ctx.createGain();
        
        // Low-frequency atmospheric engine hum
        this.humOsc.type = "sine";
        this.humOsc.frequency.setValueAtTime(55, t); // A1 note
        
        // Tremolo effect using a sub-oscillator
        const lfo = this.ctx.createOscillator();
        const lfoGain = this.ctx.createGain();
        lfo.frequency.setValueAtTime(0.5, t); // 0.5Hz modulation
        lfoGain.gain.setValueAtTime(5, t); // +/- 5Hz
        
        lfo.connect(lfoGain);
        lfoGain.connect(this.humOsc.frequency);
        
        this.humGain.gain.setValueAtTime(0, t);
        this.humGain.gain.linearRampToValueAtTime(this.volume * 0.04, t + 1.0); // fade in
        
        this.humOsc.connect(this.humGain);
        this.humGain.connect(this.ctx.destination);
        
        lfo.start(t);
        this.humOsc.start(t);
        
        this.isHumming = true;
      } catch (e) {
        console.error("Hum start error:", e);
      }
    } else if (!active && this.isHumming) {
      if (this.humGain && this.ctx) {
        try {
          const t = this.ctx.currentTime;
          this.humGain.gain.cancelScheduledValues(t);
          this.humGain.gain.setValueAtTime(this.humGain.gain.value, t);
          this.humGain.gain.linearRampToValueAtTime(0, t + 0.5); // fade out
          
          const oscToStop = this.humOsc;
          setTimeout(() => {
            try {
              oscToStop?.stop();
            } catch (err) {}
          }, 600);
        } catch (e) {
          console.error("Hum stop error:", e);
        }
      }
      this.humOsc = null;
      this.humGain = null;
      this.isHumming = false;
    }
  }

  playLaser() {
    this.init();
    if (!this.ctx || this.volume === 0) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = "sawtooth";
    osc.frequency.setValueAtTime(1500, t);
    osc.frequency.exponentialRampToValueAtTime(80, t + 0.25);

    gain.gain.setValueAtTime(this.volume * 0.12, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.25);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(t);
    osc.stop(t + 0.26);
  }

  playPulse() {
    this.init();
    if (!this.ctx || this.volume === 0) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = "triangle";
    osc.frequency.setValueAtTime(90, t);
    osc.frequency.exponentialRampToValueAtTime(180, t + 0.15);

    gain.gain.setValueAtTime(this.volume * 0.25, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.16);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(t);
    osc.stop(t + 0.17);
  }

  playAlarm() {
    this.init();
    if (!this.ctx || this.volume === 0) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = "sine";
    osc.frequency.setValueAtTime(600, t);
    // Oscillate frequency for 0.4 seconds
    osc.frequency.linearRampToValueAtTime(900, t + 0.1);
    osc.frequency.linearRampToValueAtTime(600, t + 0.2);
    osc.frequency.linearRampToValueAtTime(900, t + 0.3);
    osc.frequency.linearRampToValueAtTime(600, t + 0.4);

    gain.gain.setValueAtTime(this.volume * 0.1, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.45);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(t);
    osc.stop(t + 0.46);
  }

  playStatic() {
    this.init();
    if (!this.ctx || this.volume === 0) return;

    const t = this.ctx.currentTime;
    const bufferSize = this.ctx.sampleRate * 0.12; // 120ms burst
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    // Filter white noise for retro cyber friction
    const filter = this.ctx.createBiquadFilter();
    filter.type = "bandpass";
    filter.frequency.value = 1000;

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(this.volume * 0.15, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + 0.12);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.ctx.destination);

    noise.start(t);
    noise.stop(t + 0.13);
  }

  isHumActive() {
    return this.isHumming;
  }
}

export const sound = new SoundEngine();
