import React, { useState } from "react";
import { ThemeColors } from "../types";
import { sound } from "./SoundEngine";
import { Music, Radio, Volume2, ShieldAlert, Zap, Cpu } from "lucide-react";

interface SoundPadProps {
  theme: ThemeColors;
  onSystemLog: (text: string, type: "system" | "error" | "output") => void;
}

export default function SoundPad({ theme, onSystemLog }: SoundPadProps) {
  const [pitch, setPitch] = useState<number>(1.0);
  const [activePreset, setActivePreset] = useState<string>("neutral");

  const playSynthesizer = (type: string) => {
    switch (type) {
      case "click":
        sound.playClick(pitch);
        onSystemLog(`>> TRIGGER SYNERGY NODE [CLICK] AT PITCH: ${pitch.toFixed(2)}x`, "system");
        break;
      case "beep":
        sound.playBeep();
        onSystemLog(">> TRIGGER BEACON WAVEFORM [BEEP] - OSCILLATION ACTIVE", "system");
        break;
      case "error":
        sound.playError();
        onSystemLog(">> WARNING: HIGH-VOLTAGE EMULATED FAULT PULSE [ERROR]", "error");
        break;
      case "boot":
        sound.playBoot();
        onSystemLog(">> EVO ARPEGGIATED SYSTEM CHORD [BOOT SUCCESS] RETRIEVED", "system");
        break;
      case "laser":
        sound.playLaser();
        onSystemLog(">> COGNITIVE BEAM SCAN [LASER EFFECT]", "system");
        break;
      case "pulse":
        sound.playPulse();
        onSystemLog(">> SUB-BASS TRANSIENT PULSE TRIGGERED", "system");
        break;
      case "alarm":
        sound.playAlarm();
        onSystemLog(">> COBALT WARNING SIREN [ALARM SEQUENCE ACTIVE]", "error");
        break;
      case "static":
        sound.playStatic();
        onSystemLog(">> ANALOG SIGNAL FRICTION BURST [STATIC NOISE]", "output");
        break;
    }
  };

  const handlePitchChange = (val: number) => {
    setPitch(val);
    sound.playClick(val);
  };

  return (
    <div className="h-full flex flex-col justify-between font-mono p-4 space-y-3">
      {/* Header */}
      <div className="border-b pb-2 flex justify-between items-center" style={{ borderColor: theme.border }}>
        <div className="flex items-center space-x-2">
          <Music size={14} className="animate-bounce-slow" style={{ color: theme.primary }} />
          <span className="text-xs uppercase font-bold tracking-widest" style={{ color: theme.primary }}>
            // EVO AUDIO SYNTH BLOCK
          </span>
        </div>
        <span className="text-[9px] px-1.5 py-0.5 rounded border border-green-500/30 text-green-400 font-bold uppercase">
          LIVE OUTPUT
        </span>
      </div>

      <p className="text-[10px] opacity-70 leading-relaxed" style={{ color: theme.text }}>
        Interactive frequency matrix coupling directly into the Web Audio synthesizer. Trigger custom waveform modulators below.
      </p>

      {/* Grid of Interactive Sound Nodes */}
      <div className="grid grid-cols-4 gap-1.5 flex-1 min-h-0">
        {[
          { key: "click", label: "NODE CLICK", icon: <Zap size={11} />, desc: "High Sinusoidal Tick" },
          { key: "beep", label: "BEACON BEEP", icon: <Radio size={11} />, desc: "Triangle Arpeggiator" },
          { key: "laser", label: "CYBER BEAM", icon: <Cpu size={11} />, desc: "High Sawtooth Down" },
          { key: "pulse", label: "BASS PULSE", icon: <Music size={11} />, desc: "90Hz Sub-Transient" },
          { key: "static", label: "FRICTION", icon: <Radio size={11} />, desc: "Filtered Static Burst" },
          { key: "boot", label: "ARPEGGIO", icon: <Music size={11} />, desc: "C-Major Boot Ascent" },
          { key: "error", label: "ALERT BEAT", icon: <ShieldAlert size={11} />, desc: "Sisson Sawtooth Pair" },
          { key: "alarm", label: "SIREN LOOP", icon: <ShieldAlert size={11} />, desc: "Dual Oscillating Sine" },
        ].map((pad) => (
          <button
            key={pad.key}
            onClick={() => playSynthesizer(pad.key)}
            className="flex flex-col justify-between items-center p-2 rounded border bg-black/40 text-center select-none active:bg-green-500/20 hover:bg-white/5 transition-all group cursor-pointer"
            style={{ borderColor: theme.border }}
          >
            <div className="p-1 rounded-full group-active:scale-90 transition-transform mb-1" style={{ color: theme.primary }}>
              {pad.icon}
            </div>
            <span className="text-[8px] font-bold tracking-tight text-white uppercase group-hover:text-green-300">{pad.label}</span>
            <span className="text-[6.5px] opacity-40 mt-1" style={{ color: theme.text }}>{pad.desc}</span>
          </button>
        ))}
      </div>

      {/* Pitch Slider Modulator */}
      <div className="bg-black/50 border rounded p-2.5 text-[10px] space-y-2" style={{ borderColor: theme.border }}>
        <div className="flex justify-between items-center text-[9px] font-bold tracking-widest" style={{ color: theme.primary }}>
          <span>PITCH MODULATOR COUPLER</span>
          <span className="text-white">{pitch.toFixed(2)}x</span>
        </div>
        <div className="flex items-center space-x-3">
          <span className="opacity-50 text-[8px]">-0.5</span>
          <input
            type="range"
            min="0.4"
            max="2.5"
            step="0.05"
            value={pitch}
            onChange={(e) => handlePitchChange(parseFloat(e.target.value))}
            className="flex-1 h-1 bg-black rounded appearance-none cursor-pointer accent-current"
            style={{ color: theme.primary }}
          />
          <span className="opacity-50 text-[8px]">+2.5</span>
        </div>
      </div>
    </div>
  );
}
