import React, { useEffect, useRef } from "react";
import { ThemeColors } from "../types";

interface MatrixRainProps {
  theme: ThemeColors;
  speedMultiplier?: number;
}

export default function MatrixRain({ theme, speedMultiplier = 1.0 }: MatrixRainProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Set high density dimensions
    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resizeCanvas();
    window.addEventListener("resize", resizeCanvas);

    // Matrix characters - mixing katakana, letters, and numbers
    const chars = "ｦｧｨｩｪｫｬｭｮｯｰｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜﾝ1234567890ABCDEF$#@&*";
    const charArray = chars.split("");

    const fontSize = 14;
    const columns = Math.floor(canvas.width / fontSize) + 1;
    const drops = Array(columns).fill(1);

    let animId: number;

    const draw = () => {
      // Semi-transparent black background to generate tail trail
      ctx.fillStyle = "rgba(0, 0, 0, 0.08)";
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.fillStyle = theme.primary;
      ctx.font = `${fontSize}px monospace`;

      for (let i = 0; i < drops.length; i++) {
        // Random character
        const text = charArray[Math.floor(Math.random() * charArray.length)];
        const x = i * fontSize;
        const y = drops[i] * fontSize;

        // Draw character
        ctx.fillText(text, x, y);

        // Highlight first drop character occasionally
        if (Math.random() > 0.97) {
          ctx.fillStyle = "#ffffff";
          ctx.fillText(text, x, y);
          ctx.fillStyle = theme.primary;
        }

        // Increment drop row
        drops[i] += 1 * speedMultiplier;

        // Reset drop when hitting bottom
        if (y > canvas.height && Math.random() > 0.975) {
          drops[i] = 0;
        }
      }

      animId = requestAnimationFrame(draw);
    };

    const interval = setTimeout(() => {
      draw();
    }, 30);

    return () => {
      window.removeEventListener("resize", resizeCanvas);
      cancelAnimationFrame(animId);
      clearTimeout(interval);
    };
  }, [theme, speedMultiplier]);

  return (
    <canvas 
      ref={canvasRef} 
      className="absolute inset-0 pointer-events-none opacity-20 transition-opacity duration-1000 z-0" 
    />
  );
}
