import { useEffect, useState, useRef } from "react";
import { ThemeColors } from "../types";
import { sound } from "./SoundEngine";

interface SystemMonitorProps {
  theme: ThemeColors;
}

export default function SystemMonitor({ theme }: SystemMonitorProps) {
  const [stats, setStats] = useState<any>(null);
  const [history, setHistory] = useState<number[]>(Array(30).fill(25));
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Fetch from our safe full-stack API
  useEffect(() => {
    let active = true;
    const fetchStats = async () => {
      try {
        const res = await fetch("/api/sysinfo");
        if (res.ok) {
          const data = await res.json();
          if (active) {
            setStats(data);
            setHistory(prev => {
              const next = [...prev.slice(1), data.cpu.load];
              return next;
            });
          }
        }
      } catch (err) {
        // Fallback mock if api is unavailable during build
        if (active) {
          const mockLoad = Math.floor(Math.random() * 30) + 10;
          setHistory(prev => [...prev.slice(1), mockLoad]);
          setStats({
            platform: "linux",
            arch: "x64",
            uptime: Math.floor(Date.now() / 1000) % 100000,
            cpu: { model: "AMD EPYC Processor", speed: 2200, cores: 8, load: mockLoad },
            memory: { total: 16 * 1024 * 1024 * 1024, used: 6.4 * 1024 * 1024 * 1024, percent: 40 },
            disk: { total: 100 * 1024 * 1024 * 1024, used: 42 * 1024 * 1024 * 1024, percent: 42 },
            network: { ping: 12, bytesReceived: 1024, bytesSent: 512 },
            coreTemp: 52,
            nodeVersion: "v20.10.0"
          });
        }
      }
    };

    fetchStats();
    const interval = setInterval(fetchStats, 1500);
    return () => {
      active = false;
      clearInterval(interval);
    };
  }, []);

  // Live Canvas Waveform Drawing for Network/CPU Oscillation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animId: number;
    let offset = 0;

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const w = canvas.width;
      const h = canvas.height;

      // Draw Grid
      ctx.strokeStyle = theme.border;
      ctx.lineWidth = 0.5;
      for (let x = 0; x < w; x += 15) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
      }
      for (let y = 0; y < h; y += 15) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }

      // Drawing Simulated Oscilloscope Waveform (representing network traffic)
      ctx.strokeStyle = theme.primary;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      for (let x = 0; x < w; x++) {
        const amplitude = h * 0.25;
        const frequency = 0.03;
        // Dual sine-wave overlay
        const y = h * 0.5 + 
          Math.sin(x * frequency + offset) * amplitude + 
          Math.sin(x * 0.01 + offset * 1.5) * (amplitude * 0.4);
        
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();

      // Ambient Glow line
      ctx.shadowBlur = 8;
      ctx.shadowColor = theme.primary;
      ctx.strokeStyle = theme.primary;
      ctx.stroke();
      ctx.shadowBlur = 0; // reset

      offset += 0.05;
      animId = requestAnimationFrame(draw);
    };

    draw();
    return () => cancelAnimationFrame(animId);
  }, [theme]);

  if (!stats) {
    return (
      <div className="h-full flex items-center justify-center p-4">
        <div className="text-center font-mono animate-pulse" style={{ color: theme.primary }}>
          [CONNECTING TO HOST TELEMETRY...]
        </div>
      </div>
    );
  }

  // Format Bytes helper
  const formatBytes = (bytes: number) => {
    if (bytes === 0) return "0 B";
    const k = 1024;
    const sizes = ["B", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
  };

  // Format Uptime helper
  const formatUptime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    return `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  };

  return (
    <div className="h-full flex flex-col justify-between font-mono p-4 overflow-y-auto space-y-4">
      {/* 1. Header Details */}
      <div className="border-b pb-2 flex justify-between items-center" style={{ borderColor: theme.border }}>
        <span className="text-xs uppercase font-bold tracking-widest" style={{ color: theme.primary }}>
          // HARDWARE TELEMETRY
        </span>
        <span className="text-[10px] opacity-75" style={{ color: theme.text }}>
          OS: {stats.platform} ({stats.arch})
        </span>
      </div>

      {/* 2. CPU Segment */}
      <div className="space-y-1">
        <div className="flex justify-between text-xs">
          <span style={{ color: theme.text }}>CPU LOAD:</span>
          <span className="font-bold" style={{ color: theme.primary }}>{stats.cpu.load}%</span>
        </div>
        
        {/* Core representation grids */}
        <div className="grid grid-cols-4 gap-1">
          {Array.from({ length: stats.cpu.cores }).map((_, i) => {
            // Distribute loads slightly differently for visual variance
            const variance = Math.sin(i * 1.5 + Date.now() * 0.001) * 15;
            const coreLoad = Math.max(5, Math.min(99, Math.round(stats.cpu.load + variance)));
            return (
              <div 
                key={i} 
                className="border p-1 text-[9px] flex flex-col justify-between transition-all duration-300"
                style={{ 
                  borderColor: theme.border,
                  backgroundColor: coreLoad > 75 ? "rgba(239, 68, 68, 0.1)" : theme.panelBg 
                }}
              >
                <div className="text-left text-[8px] opacity-50" style={{ color: theme.text }}>C{i}</div>
                <div className="h-1.5 w-full bg-black/50 rounded-sm overflow-hidden mt-1 relative">
                  <div 
                    className="h-full transition-all duration-500 rounded-sm"
                    style={{ 
                      width: `${coreLoad}%`, 
                      backgroundColor: theme.primary,
                      boxShadow: `0 0 4px ${theme.primary}` 
                    }}
                  />
                </div>
                <div className="text-right font-bold mt-1" style={{ color: coreLoad > 75 ? "rgb(239,68,68)" : theme.primary }}>
                  {coreLoad}%
                </div>
              </div>
            );
          })}
        </div>
        <div className="text-[9px] opacity-60 text-right uppercase mt-1" style={{ color: theme.text }}>
          {stats.cpu.model.replace(/\((R)\)|\((TM)\)/g, "")} @ {stats.cpu.speed}MHz
        </div>
      </div>

      {/* 3. Memory & Disk Progress Section */}
      <div className="grid grid-cols-2 gap-4">
        {/* Memory Gauges */}
        <div className="border p-2 flex flex-col justify-between" style={{ borderColor: theme.border, backgroundColor: theme.panelBg }}>
          <div className="text-[10px] tracking-wide" style={{ color: theme.text }}>RAM CONSUMPTION</div>
          <div className="my-2 relative flex items-center justify-center">
            {/* SVG circle meter */}
            <svg className="w-16 h-16 transform -rotate-90">
              <circle cx="32" cy="32" r="26" stroke={theme.border} strokeWidth="3" fill="transparent" />
              <circle 
                cx="32" cy="32" r="26" 
                stroke={theme.primary} 
                strokeWidth="4" 
                fill="transparent" 
                strokeDasharray={2 * Math.PI * 26}
                strokeDashoffset={2 * Math.PI * 26 * (1 - stats.memory.percent / 100)}
                className="transition-all duration-500"
                style={{ filter: `drop-shadow(0 0 2px ${theme.primary})` }}
              />
            </svg>
            <div className="absolute text-[11px] font-bold" style={{ color: theme.primary }}>
              {stats.memory.percent}%
            </div>
          </div>
          <div className="text-[9px] text-center opacity-75" style={{ color: theme.text }}>
            {formatBytes(stats.memory.used)} / {formatBytes(stats.memory.total)}
          </div>
        </div>

        {/* Storage */}
        <div className="border p-2 flex flex-col justify-between" style={{ borderColor: theme.border, backgroundColor: theme.panelBg }}>
          <div className="text-[10px] tracking-wide" style={{ color: theme.text }}>STORAGE DRIVE (/)</div>
          <div className="my-2 flex flex-col justify-center space-y-1">
            <div className="h-4 w-full bg-black/50 border relative" style={{ borderColor: theme.border }}>
              <div 
                className="h-full transition-all duration-1000"
                style={{ 
                  width: `${stats.disk.percent}%`, 
                  backgroundColor: theme.primary,
                  boxShadow: `0 0 5px ${theme.primary}`
                }}
              />
              <span className="absolute inset-0 text-[10px] font-bold flex items-center justify-center text-white mix-blend-difference">
                {stats.disk.percent}%
              </span>
            </div>
            <div className="text-[8px] text-center opacity-75 mt-1" style={{ color: theme.text }}>
              USED: {formatBytes(stats.disk.used)}
            </div>
            <div className="text-[8px] text-center opacity-50 font-mono" style={{ color: theme.text }}>
              FS CAPACITY: {formatBytes(stats.disk.total)}
            </div>
          </div>
        </div>
      </div>

      {/* 4. Canvas Real-Time Signal Monitor */}
      <div className="border rounded p-1 flex flex-col" style={{ borderColor: theme.border, backgroundColor: "rgba(0,0,0,0.4)" }}>
        <div className="flex justify-between items-center px-1 py-0.5 text-[9px] uppercase tracking-wider" style={{ color: theme.primary }}>
          <span>// CORE ATMOSPHERE OSCILLOSCOPE</span>
          <span>TEMP: {stats.coreTemp}°C</span>
        </div>
        <canvas 
          ref={canvasRef} 
          width={280} 
          height={65} 
          className="w-full bg-black rounded"
        />
      </div>

      {/* 5. Network Traffic Indicators */}
      <div className="grid grid-cols-3 gap-1 text-center text-[10px] pt-1">
        <div className="border p-1 rounded-sm" style={{ borderColor: theme.border }}>
          <div className="opacity-50 text-[8px]" style={{ color: theme.text }}>NET PING</div>
          <div className="font-bold text-xs" style={{ color: theme.primary }}>{stats.network.ping} ms</div>
        </div>
        <div className="border p-1 rounded-sm" style={{ borderColor: theme.border }}>
          <div className="opacity-50 text-[8px]" style={{ color: theme.text }}>RX RATE</div>
          <div className="font-bold text-[10px]" style={{ color: theme.primary }}>{formatBytes(stats.network.bytesReceived)}/s</div>
        </div>
        <div className="border p-1 rounded-sm" style={{ borderColor: theme.border }}>
          <div className="opacity-50 text-[8px]" style={{ color: theme.text }}>TX RATE</div>
          <div className="font-bold text-[10px]" style={{ color: theme.primary }}>{formatBytes(stats.network.bytesSent)}/s</div>
        </div>
      </div>

      {/* 6. System Uptime Details */}
      <div className="text-[10px] text-center opacity-65 flex justify-between px-1" style={{ color: theme.text }}>
        <span>UPTIME: {formatUptime(stats.uptime)}</span>
        <span>NODE: {stats.nodeVersion}</span>
      </div>
    </div>
  );
}
