import { useEffect, useState } from "react";
import { ThemeColors } from "../types";
import { sound } from "./SoundEngine";

interface VirtualKeyboardProps {
  theme: ThemeColors;
  onKeyPress: (key: string) => void;
}

export default function VirtualKeyboard({ theme, onKeyPress }: VirtualKeyboardProps) {
  const [activeKeys, setActiveKeys] = useState<Set<string>>(new Set());

  // Listen to physical keyboard presses to light up virtual keys
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      let k = e.key.toLowerCase();
      // Translate names
      if (k === " ") k = "space";
      if (k === "control") k = "ctrl";
      if (k === "backspace") k = "back";
      if (k === "arrowleft") k = "left";
      if (k === "arrowright") k = "right";
      if (k === "arrowup") k = "up";
      if (k === "arrowdown") k = "down";

      setActiveKeys(prev => {
        const next = new Set(prev);
        next.add(k);
        return next;
      });

      // Quick synth clicking
      sound.playClick(Math.random() * 0.4 + 0.85);
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      let k = e.key.toLowerCase();
      if (k === " ") k = "space";
      if (k === "control") k = "ctrl";
      if (k === "backspace") k = "back";
      if (k === "arrowleft") k = "left";
      if (k === "arrowright") k = "right";
      if (k === "arrowup") k = "up";
      if (k === "arrowdown") k = "down";

      setActiveKeys(prev => {
        const next = new Set(prev);
        next.delete(k);
        return next;
      });
    };

    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("keyup", handleKeyUp);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("keyup", handleKeyUp);
    };
  }, []);

  const handleKeyClick = (keyVal: string) => {
    // Synth audio
    sound.playClick(1.1);
    
    // Briefly animate click active
    setActiveKeys(prev => {
      const next = new Set(prev);
      next.add(keyVal);
      return next;
    });
    setTimeout(() => {
      setActiveKeys(prev => {
        const next = new Set(prev);
        next.delete(keyVal);
        return next;
      });
    }, 1200);

    // Call terminal typing handler
    onKeyPress(keyVal);
  };

  const rows = [
    ["esc", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-", "=", "back"],
    ["tab", "q", "w", "e", "r", "t", "y", "u", "i", "o", "p", "[", "]", "\\"],
    ["ctrl", "a", "s", "d", "f", "g", "h", "j", "k", "l", ";", "'", "enter"],
    ["shift", "z", "x", "c", "v", "b", "n", "m", ",", ".", "/", "up"],
    ["alt", "space", "left", "down", "right"]
  ];

  // Width classes helper
  const getKeyWidth = (key: string) => {
    switch (key) {
      case "space": return "flex-1 min-w-[120px] md:min-w-[240px]";
      case "back": return "w-12 md:w-16";
      case "tab": return "w-10 md:w-12";
      case "enter": return "w-14 md:w-20";
      case "shift": return "w-16 md:w-24";
      case "ctrl": return "w-12 md:w-14";
      case "alt": return "w-12 md:w-14";
      case "esc": return "w-10 md:w-12 text-red-400";
      default: return "w-8 md:w-10";
    }
  };

  return (
    <div className="w-full flex flex-col items-center justify-center p-3 select-none space-y-1 bg-black/40 border rounded" style={{ borderColor: theme.border }}>
      {rows.map((row, rIdx) => (
        <div key={rIdx} className="flex justify-center w-full space-x-[2px] md:space-x-1">
          {row.map((k) => {
            const isActive = activeKeys.has(k);
            return (
              <button
                key={k}
                onClick={() => handleKeyClick(k)}
                className={`h-7 md:h-9 rounded flex items-center justify-center text-[9px] md:text-xs font-mono font-bold tracking-tight uppercase cursor-pointer border transition-all duration-75 ${getKeyWidth(k)}`}
                style={{
                  backgroundColor: isActive ? theme.primary : "rgba(255,255,255,0.02)",
                  borderColor: isActive ? "white" : theme.border,
                  color: isActive ? "black" : theme.text,
                  boxShadow: isActive ? `0 0 12px ${theme.primary}` : "none",
                }}
              >
                {k === "space" ? "SPACEBAR" : k}
              </button>
            );
          })}
        </div>
      ))}
    </div>
  );
}
