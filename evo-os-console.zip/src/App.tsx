import React, { useEffect, useState, useRef } from "react";
import { 
  Terminal as TerminalIcon, 
  Settings, 
  Volume2, 
  VolumeX, 
  Cpu, 
  Maximize2, 
  Activity, 
  HelpCircle,
  Clock,
  Sparkles,
  Shield,
  RefreshCw,
  Power,
  ChevronRight
} from "lucide-react";
import { THEMES, ThemeType, TerminalLog, FileItem } from "./types";
import { sound } from "./components/SoundEngine";
import SystemMonitor from "./components/SystemMonitor";
import FileExplorer from "./components/FileExplorer";
import ProcessManager from "./components/ProcessManager";
import VirtualKeyboard from "./components/VirtualKeyboard";
import MatrixRain from "./components/MatrixRain";
import HackSimulator from "./components/HackSimulator";
import SoundPad from "./components/SoundPad";

export default function App() {
  const [themeKey, setThemeKey] = useState<ThemeType>("matrix");
  const theme = THEMES[themeKey];

  const [activeRightTab, setActiveRightTab] = useState<"files" | "decryptor" | "soundpad">("files");
  const [matrixRainOn, setMatrixRainOn] = useState<boolean>(true);
  const [matrixRainSpeed, setMatrixRainSpeed] = useState<number>(1.0);

  const [booting, setBooting] = useState<boolean>(true);
  const [bootProgress, setBootProgress] = useState<string[]>([]);
  const [bootStep, setBootStep] = useState<number>(0);
  const [audioEnabled, setAudioEnabled] = useState<boolean>(false);
  const [humActive, setHumActive] = useState<boolean>(false);
  const [volume, setVolume] = useState<number>(0.4);

  // Terminal state
  const [terminalLogs, setTerminalLogs] = useState<TerminalLog[]>([
    { id: "1", text: ">> EVO COGNITIVE OS HUD CORE ACTIVE.", type: "system" },
    { id: "2", text: ">> SESSION AUTHORIZED BY CREATOR: EricLM (LEVEL 10 MASTER ACCESS).", type: "system" },
    { id: "3", text: ">> ENTER 'help' TO VIEW COMMAND SETS OR PRESS TOUCHPAD CONTROLS.", type: "system" },
  ]);
  const [commandInput, setCommandInput] = useState<string>("");
  const [commandHistory, setCommandHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState<number>(-1);
  const [currentTime, setCurrentTime] = useState<string>("");
  const [uptimeSeconds, setUptimeSeconds] = useState<number>(51210);

  const logsEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Boot sequence simulated steps
  const bootSteps = [
    "LOADING EVO COGNITIVE OS INTERFACE...",
    "VERIFYING SECURITY CREDENTIALS [ROOT]...",
    "ACCESS AUTHORIZED TO CREATOR: EricLM [LEVEL 10 MASTER]",
    "SYNTHESIZING ATMOSPHERIC SOUND OSCILLATORS...",
    "ACQUIRING NEURAL GATEWAY PROTOCOLS...",
    "MOUNTING SECURE MEMORY BLOCK ALLOCATIONS...",
    "ESTABLISHING SYSTEM HUDS AND SPECTROGRAMS...",
    "EVO CORE OS RUNNING IN GREEN MATRIX MODE [READY].",
  ];

  // System real-time clock and uptime simulation
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString("pt-BR", { hour12: false })
      );
    };
    updateTime();
    const tInterval = setInterval(updateTime, 1000);

    const uInterval = setInterval(() => {
      setUptimeSeconds(prev => prev + 1);
    }, 1000);

    return () => {
      clearInterval(tInterval);
      clearInterval(uInterval);
    };
  }, []);

  // Scroll terminal logs to bottom when updated
  useEffect(() => {
    logsEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [terminalLogs]);

  // Handle Boot progression
  useEffect(() => {
    if (!booting) return;
    if (bootStep < bootSteps.length) {
      const timeout = setTimeout(() => {
        setBootProgress(prev => [...prev, `[OK] ${bootSteps[bootStep]}`]);
        setBootStep(prev => prev + 1);
      }, 500);
      return () => clearTimeout(timeout);
    }
  }, [bootStep, booting]);

  const handleStartCore = () => {
    setBooting(false);
    setAudioEnabled(true);
    setHumActive(true);
    
    // Play sci-fi sounds
    sound.setVolume(volume);
    sound.playBoot();
    sound.toggleHum(true);
  };

  const toggleSound = () => {
    const nextState = !audioEnabled;
    setAudioEnabled(nextState);
    if (!nextState) {
      sound.toggleHum(false);
      setHumActive(false);
    } else {
      sound.setVolume(volume);
      sound.toggleHum(true);
      setHumActive(true);
      sound.playClick(1.0);
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVol = parseFloat(e.target.value);
    setVolume(newVol);
    sound.setVolume(newVol);
    if (newVol === 0) {
      sound.toggleHum(false);
      setHumActive(false);
    } else if (audioEnabled && !humActive) {
      sound.toggleHum(true);
      setHumActive(true);
    }
  };

  const handleToggleHum = () => {
    if (!audioEnabled) return;
    const nextHum = !humActive;
    setHumActive(nextHum);
    sound.toggleHum(nextHum);
    sound.playClick(1.2);
  };

  // Run a single shell command inside the dynamic client execution pipe
  const executeCommand = async (rawCmd: string) => {
    const trimmed = rawCmd.trim();
    if (!trimmed) return;

    // Add to command history
    setCommandHistory(prev => [trimmed, ...prev]);
    setHistoryIndex(-1);

    // Append raw input line to terminal logs
    setTerminalLogs(prev => [
      ...prev,
      { id: Date.now().toString() + "-input", text: `ericlm@evo-os:~# ${trimmed}`, type: "input" }
    ]);

    const args = trimmed.split(" ");
    const cmd = args[0].toLowerCase();

    // Sound click feedback
    sound.playClick(1.0);

    switch (cmd) {
      case "help":
      case "?":
        setTerminalLogs(prev => [
          ...prev,
          { 
            id: Date.now().toString(), 
            text: `AVAILABLE EVO OS SYSTEM CONTROL CHANNELS:
  - neofetch / sysinfo  : Print sci-fi specifications layout card
  - creator / ericlm    : Display EVO OS mastermind creator profile
  - soundpad / synth    : Toggle active sound wave synthesizer pad
  - ports / portscan    : Initiate high-speed simulation network scan
  - ls [dir_path]       : List workspace files in current folder
  - cat [file_path]     : Print contents of target file
  - ai [prompt]         : Transmit custom queries to central Gemini Core AI Mainframe
  - hack [target]       : Engage high-speed mainframe brute force decrypter tab
  - matrix / rain       : Toggle background binary digital waterfall stream rain
  - matrix speed [val]  : Set rain fall speed multiplier (e.g. 0.5, 2.0)
  - env                 : View secure mainframe environment variables
  - hash [text]         : Convert text payload into hex signature hashes
  - theme [name]        : Swap UI colors (tron, matrix, amber, sanguine, chrome)
  - sound [on/off]      : Enable/disable the ambient atmospheric oscillator
  - clear / cls         : Purge the console log visual lines
  - ping                : Test dynamic round-trip payload metrics`, 
            type: "system" 
          }
        ]);
        break;

      case "creator":
      case "ericlm":
        setTerminalLogs(prev => [
          ...prev,
          {
            id: Date.now().toString(),
            text: `
           _______      _____    ____
          | ____\\ \\    / / _ \\  / ___|
          |  _|  \\ \\  / / | | | \\___ \\
          | |___  \\ \\/ /| |_| |  ___) |
          |_____|  \\__/  \\___/  |____/

  ======================================================
  EVO HUD CORE MASTERMIND COGNITIVE SCHEMATICS
  ======================================================
  DEVELOPER & CREATOR  : EricLM
  OS COUPLING LEVEL    : LEVEL 10 ADMIN
  CENTRAL SHELL ACCESS : MASTER GRANTED
  INTELLIGENCE PARTNER : Google Gemini-3.5-Flash
  COMPILING YEAR       : 2026
  SIGNATURE KEY        : 0x9B44F23F2A0328CE0A71E9D70B9F7
  ======================================================`,
            type: "output"
          }
        ]);
        sound.playBoot();
        break;

      case "soundpad":
      case "synth":
        setActiveRightTab("soundpad");
        setTerminalLogs(prev => [
          ...prev,
          { id: Date.now().toString(), text: ">> ROUTING PAYLOAD ENGINES TO CENTRAL AUDIO SYNTHESIZER TOUCHPAD CONTROLS.", type: "system" }
        ]);
        sound.playLaser();
        break;

      case "ports":
      case "portscan":
        setTerminalLogs(prev => [
          ...prev,
          { id: Date.now().toString(), text: ">> INITIATING COGNITIVE SECURE NETWORK PORT SCAN PROTOCOL...", type: "system" }
        ]);
        setTimeout(() => {
          setTerminalLogs(prev => [
            ...prev,
            { id: Date.now().toString(), text: `[+] SCAN COMPLETE. OPEN TARGET VECTOR PORTS REVEALED:
  - PORT 22   : SSH (SECURE COUPLING EXPLOITABLE)
  - PORT 80   : HTTP (UNENCRYPTED HEADER PACKETS)
  - PORT 443  : HTTPS (COGNITIVE MAIN GATEWAY)
  - PORT 3000 : EVO LOCAL HUD PROTOCOL (STABLE ACTIVE INGRESS)`, type: "output" }
          ]);
          sound.playBeep();
        }, 1200);
        break;

      case "matrix":
      case "rain":
        if (args[1] === "speed") {
          const speedVal = parseFloat(args[2]);
          if (!isNaN(speedVal) && speedVal > 0) {
            setMatrixRainSpeed(speedVal);
            setTerminalLogs(prev => [
              ...prev,
              { id: Date.now().toString(), text: `>> DIGITAL WATERFALL STREAM SPEED MULTIPLIER CONFIGURED TO: [${speedVal}x]`, type: "system" }
            ]);
            sound.playClick(1.2);
          } else {
            setTerminalLogs(prev => [
              ...prev,
              { id: Date.now().toString(), text: ">> Usage: matrix speed [positive_number]", type: "error" }
            ]);
          }
        } else {
          setMatrixRainOn(prev => {
            const next = !prev;
            setTerminalLogs(l => [
              ...l,
              { id: Date.now().toString(), text: `>> COGNITIVE BACKGROUND RAIN SET TO: [${next ? "ACTIVE" : "STALE"}].`, type: "system" }
            ]);
            return next;
          });
        }
        break;

      case "hack":
        const hackTarget = args[1] || "mainframe.gov.io";
        setActiveRightTab("decryptor");
        setTerminalLogs(prev => [
          ...prev,
          { id: Date.now().toString(), text: `>> ROUTING PAYLOAD ENGINES TO COGNITIVE DECRYPTOR WITH TARGET: ${hackTarget}.`, type: "system" }
        ]);
        break;

      case "env":
        setTerminalLogs(prev => [
          ...prev,
          {
            id: Date.now().toString(),
            text: `>> CENTRAL CONFIG ENVIRONMENT VALUES:
  APP_URL=${process.env.APP_URL || "https://ai.studio/build"}
  NODE_ENV=${process.env.NODE_ENV || "development"}
  AI_MAIN_CORE=GEMINI-3.5-FLASH-COGNITIVE
  SECURE_SSL_PORT=3000
  ENGINE_HUM_HZ=55.0`,
            type: "output"
          }
        ]);
        break;

      case "hash":
        const textToHash = args.slice(1).join(" ");
        if (!textToHash) {
          setTerminalLogs(prev => [...prev, { id: Date.now().toString(), text: ">> Usage: hash [text_to_convert]", type: "error" }]);
        } else {
          let h = 0x811c9dc5;
          for (let i = 0; i < textToHash.length; i++) {
            h ^= textToHash.charCodeAt(i);
            h += (h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24);
          }
          const hashString = (h >>> 0).toString(16).toUpperCase().padStart(8, "0");
          setTerminalLogs(prev => [
            ...prev,
            { id: Date.now().toString(), text: `>> SHA-256 SIGNATURE HASH: [0x${hashString}1FF4E0D9C0A3B5749E]`, type: "output" }
          ]);
        }
        break;

      case "clear":
      case "cls":
        setTerminalLogs([]);
        break;

      case "neofetch":
      case "sysinfo":
        setTerminalLogs(prev => [
          ...prev,
          {
            id: Date.now().toString(),
            text: `
    .---.      EVO COGNITIVE SYSTEM HUD
   /     \\     OS: EVO OS v4.0.0 (Node.js ${process.version})
   \\     /     HOST: evo-cognitive-core-08
    \`---\`      CREATOR: EricLM (Level 10 Admin)
               UPTIME: ${Math.floor(uptimeSeconds / 3600)} hours, ${Math.floor((uptimeSeconds % 3600) / 60)} mins
               SHELL: Gemini-Interactive-Shell v4.0
               THEME: ${themeKey.toUpperCase()} (Green matrix default)
               SOUND: Synthesized Web Audio Generator (ON)
               API ENGINE: @google/genai (TypeScript SDK)
               DEVICES: CPU Cores (8x Live), Disk (Mount /), RAM (Visualized)`,
            type: "output"
          }
        ]);
        break;

      case "ping":
        const start = Date.now();
        try {
          const res = await fetch("/api/sysinfo");
          const duration = Date.now() - start;
          setTerminalLogs(prev => [
            ...prev,
            { id: Date.now().toString(), text: `>> PING OK. Payload round-trip: ${duration}ms. Signal status is secure.`, type: "output" }
          ]);
        } catch (err) {
          setTerminalLogs(prev => [
            ...prev,
            { id: Date.now().toString(), text: `>> ERROR: Telemetry host unreachable.`, type: "error" }
          ]);
        }
        break;

      case "theme":
        const targetTheme = args[1]?.toLowerCase() as ThemeType;
        if (THEMES[targetTheme]) {
          setThemeKey(targetTheme);
          setTerminalLogs(prev => [
            ...prev,
            { id: Date.now().toString(), text: `>> THEME SYSTEM SET TO [${targetTheme.toUpperCase()}].`, type: "system" }
          ]);
        } else {
          setTerminalLogs(prev => [
            ...prev,
            { id: Date.now().toString(), text: `>> THEME NOT FOUND. Use: theme [tron | matrix | amber | sanguine | chrome]`, type: "error" }
          ]);
        }
        break;

      case "sound":
        const arg1 = args[1]?.toLowerCase();
        if (arg1 === "on") {
          setAudioEnabled(true);
          setHumActive(true);
          sound.setVolume(volume);
          sound.toggleHum(true);
          setTerminalLogs(prev => [...prev, { id: Date.now().toString(), text: ">> SYSTEM ATMOSPHERIC AUDIO CORE ENABLED.", type: "system" }]);
        } else if (arg1 === "off") {
          setAudioEnabled(false);
          setHumActive(false);
          sound.toggleHum(false);
          setTerminalLogs(prev => [...prev, { id: Date.now().toString(), text: ">> SYSTEM ATMOSPHERIC AUDIO CORE DISABLED.", type: "system" }]);
        } else {
          setTerminalLogs(prev => [
            ...prev,
            { id: Date.now().toString(), text: `>> CURRENT VOLUME: ${Math.round(volume * 100)}%. Use 'sound on' or 'sound off'.`, type: "system" }
          ]);
        }
        break;

      case "ls":
        const lsPath = args[1] || ".";
        try {
          const res = await fetch("/api/files", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ path: lsPath }),
          });
          if (res.ok) {
            const data = await res.json();
            if (data.isDirectory) {
              const formattedList = data.items.map((item: FileItem) => {
                return item.isDirectory ? `[DIR]  ${item.name}/` : `[FILE] ${item.name} (${(item.size / 1024).toFixed(1)} KB)`;
              }).join("\n");
              setTerminalLogs(prev => [
                ...prev,
                { id: Date.now().toString(), text: `Directory listing of [${data.currentPath}]:\n${formattedList || "[Empty directory]"}`, type: "output" }
              ]);
            } else {
              setTerminalLogs(prev => [
                ...prev,
                { id: Date.now().toString(), text: `[FILE] ${data.currentPath} (${(data.size / 1024).toFixed(1)} KB)`, type: "output" }
              ]);
            }
          } else {
            const errData = await res.json();
            setTerminalLogs(prev => [
              ...prev,
              { id: Date.now().toString(), text: `>> LS FAULT: ${errData.error}`, type: "error" }
            ]);
          }
        } catch (e: any) {
          setTerminalLogs(prev => [
            ...prev,
            { id: Date.now().toString(), text: `>> LS ERROR: ${e.message}`, type: "error" }
          ]);
        }
        break;

      case "cat":
        const catPath = args[1];
        if (!catPath) {
          setTerminalLogs(prev => [...prev, { id: Date.now().toString(), text: ">> Usage: cat [file_path]", type: "error" }]);
          break;
        }
        try {
          const res = await fetch("/api/files", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ path: catPath }),
          });
          if (res.ok) {
            const data = await res.json();
            if (data.isDirectory) {
              setTerminalLogs(prev => [
                ...prev,
                { id: Date.now().toString(), text: `>> FAULT: [${catPath}] is a directory.`, type: "error" }
              ]);
            } else {
              setTerminalLogs(prev => [
                ...prev,
                { id: Date.now().toString(), text: `--- CONTENT OF [${data.currentPath}] ---\n${data.content}`, type: "output" }
              ]);
            }
          } else {
            const errData = await res.json();
            setTerminalLogs(prev => [
              ...prev,
              { id: Date.now().toString(), text: `>> CAT FAULT: ${errData.error}`, type: "error" }
            ]);
          }
        } catch (e: any) {
          setTerminalLogs(prev => [
            ...prev,
            { id: Date.now().toString(), text: `>> CAT ERROR: ${e.message}`, type: "error" }
          ]);
        }
        break;

      case "ai":
        const prompt = args.slice(1).join(" ");
        if (!prompt) {
          setTerminalLogs(prev => [
            ...prev,
            { id: Date.now().toString(), text: ">> TRANSMISSION ERROR: Please include a query. Ex: ai status diagnostic", type: "error" }
          ]);
          break;
        }
        setTerminalLogs(prev => [
          ...prev,
          { id: Date.now().toString(), text: `>> TRANSMITTING UPLINK SIGNAL TO COGNITIVE CORE...`, type: "system" }
        ]);

        try {
          const res = await fetch("/api/ai", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ prompt }),
          });
          if (res.ok) {
            const data = await res.json();
            setTerminalLogs(prev => [
              ...prev,
              { id: Date.now().toString(), text: `${data.reply}`, type: "ai" }
            ]);
          } else {
            setTerminalLogs(prev => [
              ...prev,
              { id: Date.now().toString(), text: `>> AI CENTRAL LINK REFUSED CONNECTION. CHECK SECRET KEY SETUP.`, type: "error" }
            ]);
          }
        } catch (e: any) {
          setTerminalLogs(prev => [
            ...prev,
            { id: Date.now().toString(), text: `>> COGNITIVE AI CORE EXCEPTION: ${e.message}`, type: "error" }
          ]);
        }
        break;

      default:
        // Try fallback search/ask in AI mainframe if they entered text that isn't help or standard command,
        // or offer to invoke AI
        setTerminalLogs(prev => [
          ...prev,
          { 
            id: Date.now().toString(), 
            text: `>> PROTOCOL NOT RECOGNIZED: '${cmd}'.\n>> Did you mean to query the AI mainframe? Type: 'ai ${trimmed}'`, 
            type: "error" 
          }
        ]);
        break;
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      executeCommand(commandInput);
      setCommandInput("");
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      if (commandHistory.length > 0) {
        const nextIdx = historyIndex + 1;
        if (nextIdx < commandHistory.length) {
          setHistoryIndex(nextIdx);
          setCommandInput(commandHistory[nextIdx]);
        }
      }
    } else if (e.key === "ArrowDown") {
      e.preventDefault();
      const nextIdx = historyIndex - 1;
      if (nextIdx >= 0) {
        setHistoryIndex(nextIdx);
        setCommandInput(commandHistory[nextIdx]);
      } else {
        setHistoryIndex(-1);
        setCommandInput("");
      }
    }
  };

  // Virtual Keyboard clicks callback
  const handleVirtualKeyPress = (key: string) => {
    if (key === "space") {
      setCommandInput(prev => prev + " ");
    } else if (key === "back") {
      setCommandInput(prev => prev.slice(0, -1));
    } else if (key === "enter") {
      executeCommand(commandInput);
      setCommandInput("");
    } else if (key === "esc") {
      setCommandInput("");
    } else if (key === "tab") {
      setCommandInput(prev => prev + "  ");
    } else if (key === "ctrl" || key === "alt" || key === "shift") {
      // Functional triggers, play tone
    } else if (key === "up") {
      if (commandHistory.length > 0) {
        setCommandInput(commandHistory[0]);
      }
    } else if (key === "down" || key === "left" || key === "right") {
      // Arrow feedback
    } else {
      setCommandInput(prev => prev + key);
    }
    inputRef.current?.focus();
  };

  // Callback from file list item click to auto cat content
  const handleOpenFileInTerminal = (path: string) => {
    executeCommand(`cat ${path}`);
  };

  // Format seconds to high fidelity tech counter
  const formatUptimeDisplay = (totalSec: number) => {
    const days = Math.floor(totalSec / (3600 * 24));
    const hours = Math.floor((totalSec % (3600 * 24)) / 3600);
    const mins = Math.floor((totalSec % 3600) / 60);
    const secs = totalSec % 60;
    return `${days.toString().padStart(2, "0")}:${hours.toString().padStart(2, "0")}:${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  if (booting) {
    return (
      <div className="h-screen w-screen bg-[rgb(4,12,6)] flex flex-col justify-center items-center font-mono p-4 text-green-400">
        <div className="max-w-2xl w-full border border-green-500/30 bg-green-950/10 rounded p-6 space-y-6 shadow-[0_0_30px_rgba(34,197,94,0.15)]">
          {/* Futuristic Boot Header */}
          <div className="flex justify-between items-center border-b border-green-500/30 pb-4">
            <div className="flex items-center space-x-3">
              <Power size={22} className="animate-pulse text-green-400" />
              <div className="flex flex-col">
                <span className="text-[10px] text-green-500/70 tracking-widest uppercase">System Initialization</span>
                <span className="text-lg font-bold tracking-widest text-green-200">EVO COGNITIVE OS</span>
              </div>
            </div>
            <div className="text-right flex flex-col items-end">
              <span className="text-[10px] opacity-60">EVO-BOOT-v4.0</span>
              <span className="text-[9px] text-green-500 font-bold">CREATOR: EricLM</span>
            </div>
          </div>

          {/* Sequential step status logs */}
          <div className="h-48 border border-green-950 bg-black/60 rounded p-4 overflow-y-auto text-xs space-y-2 select-none">
            {bootProgress.map((prog, idx) => (
              <div key={idx} className="flex items-center space-x-2 text-green-300">
                <span className="text-green-500 font-bold">&gt;</span>
                <span className="tracking-tight">{prog}</span>
              </div>
            ))}
            {bootStep < bootSteps.length && (
              <div className="flex items-center space-x-2 text-green-400/50 animate-pulse">
                <span>&gt;</span>
                <span>EXECUTING DIAGNOSTIC QUEUE...</span>
              </div>
            )}
          </div>

          {/* Boot Activator Trigger */}
          <div className="flex flex-col items-center justify-center space-y-2 pt-2">
            <button
              onClick={handleStartCore}
              disabled={bootStep < bootSteps.length}
              className={`w-full py-3 rounded border font-mono font-bold tracking-widest uppercase transition-all duration-300 text-center select-none ${
                bootStep >= bootSteps.length 
                  ? "border-green-400 bg-green-950/30 text-green-200 hover:bg-green-400 hover:text-black cursor-pointer hover:shadow-[0_0_15px_rgba(34,197,94,0.4)]"
                  : "border-green-950 text-green-900 cursor-not-allowed bg-black/20"
              }`}
            >
              {bootStep >= bootSteps.length ? "INITIALIZE SYSTEM HUD" : "LOADING SYSTEMS..."}
            </button>
            <p className="text-[9px] text-green-600 uppercase tracking-wider text-center">
              Requires Web Audio authorization on initialization.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div 
      className="h-screen w-screen flex flex-col justify-between overflow-hidden select-none border-2 transition-colors duration-1000 relative" 
      style={{ 
        backgroundColor: theme.bg,
        color: theme.primary,
        borderColor: theme.border
      }}
    >
      {/* Matrix rain digital stream backdrop */}
      {matrixRainOn && <MatrixRain theme={theme} speedMultiplier={matrixRainSpeed} />}

      {/* 1. TOP BAR: SYSTEM STATUS */}
      <header 
        className="flex justify-between items-center px-4 py-2 border-b bg-black/30 backdrop-blur-sm select-none"
        style={{ borderColor: theme.border }}
      >
        <div className="flex items-center space-x-4">
          <div className="flex flex-col">
            <span className="text-[9px] uppercase leading-none" style={{ color: theme.textMuted }}>EVO OS COGNITIVE HUD</span>
            <span className="text-sm font-black tracking-widest text-white">EVO-CORE-08</span>
          </div>
          <div className="h-6 w-px" style={{ backgroundColor: theme.border }}></div>
          <div className="flex flex-col">
            <span className="text-[9px] uppercase leading-none" style={{ color: theme.textMuted }}>SYSTEM CREATOR</span>
            <span className="text-xs font-bold text-green-400 font-mono tracking-tight">EricLM (Master)</span>
          </div>
          <div className="h-6 w-px" style={{ backgroundColor: theme.border }}></div>
          <div className="flex flex-col">
            <span className="text-[9px] uppercase leading-none" style={{ color: theme.textMuted }}>SYS_UPTIME</span>
            <span className="text-xs text-white font-mono tracking-tight">{formatUptimeDisplay(uptimeSeconds)}</span>
          </div>
        </div>

        {/* Center Clock */}
        <div className="flex items-center space-x-2 bg-black/40 border px-3 py-1 rounded shadow-inner" style={{ borderColor: theme.border }}>
          <Clock size={12} style={{ color: theme.primary }} className="animate-spin-slow" />
          <span className="text-sm font-bold tracking-widest text-white">{currentTime}</span>
          <span className="text-[10px] uppercase font-semibold" style={{ color: theme.primary }}>UTC</span>
        </div>

        {/* Sound Controls & Color themes */}
        <div className="flex items-center space-x-4">
          {/* Sound Controls */}
          <div className="flex items-center space-x-2 bg-black/20 border rounded px-2.5 py-1" style={{ borderColor: theme.border }}>
            <button 
              onClick={toggleSound}
              className="p-1 rounded hover:bg-white/10 transition-colors cursor-pointer"
              title="Toggle Audio Core"
            >
              {audioEnabled ? (
                <Volume2 size={13} style={{ color: theme.primary }} />
              ) : (
                <VolumeX size={13} style={{ color: theme.textMuted }} />
              )}
            </button>
            <input 
              type="range"
              min="0"
              max="1.0"
              step="0.1"
              value={volume}
              onChange={handleVolumeChange}
              className="w-16 h-1 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-current"
              style={{ color: theme.primary }}
              title={`Volume: ${Math.round(volume * 100)}%`}
            />
            <button
              onClick={handleToggleHum}
              disabled={!audioEnabled}
              className={`text-[9px] px-1.5 py-0.5 rounded font-mono font-bold uppercase transition-all ${
                !audioEnabled 
                  ? "opacity-30 cursor-not-allowed" 
                  : humActive 
                    ? "bg-emerald-950/60 text-emerald-400 border border-emerald-500/30" 
                    : "bg-red-950/40 text-red-400 border border-red-500/20"
              }`}
              title="Toggle Atmospheric Synthesized Hum Frequency"
            >
              HUM: {humActive ? "ON" : "OFF"}
            </button>
          </div>

          {/* Matrix Rain Toggle */}
          <button
            onClick={() => {
              sound.playClick(1.1);
              setMatrixRainOn(prev => !prev);
            }}
            className="text-[9px] px-2 py-1 rounded font-mono font-bold uppercase transition-all border cursor-pointer"
            style={{
              backgroundColor: matrixRainOn ? "rgba(34, 197, 94, 0.15)" : "transparent",
              color: matrixRainOn ? "rgb(34, 197, 94)" : theme.textMuted,
              borderColor: matrixRainOn ? "rgba(34, 197, 94, 0.4)" : theme.border
            }}
            title="Toggle binary rain stream backdrop"
          >
            RAIN: {matrixRainOn ? "ACTIVE" : "OFF"}
          </button>

          {/* Theme Presets */}
          <div className="flex items-center space-x-1">
            {(Object.keys(THEMES) as ThemeType[]).map((t) => (
              <button
                key={t}
                onClick={() => {
                  sound.playClick(1.2);
                  setThemeKey(t);
                }}
                className={`w-3.5 h-3.5 rounded-full border transition-transform duration-200 hover:scale-125 cursor-pointer ${
                  themeKey === t ? "border-white scale-110" : "border-transparent"
                }`}
                style={{
                  backgroundColor: THEMES[t].primary,
                  boxShadow: themeKey === t ? `0 0 6px ${THEMES[t].primary}` : "none"
                }}
                title={`Swap theme color to ${t}`}
              />
            ))}
          </div>
        </div>
      </header>

      {/* 2. MAIN HUB CONTAINER */}
      <main className="flex-1 min-h-0 grid grid-cols-12 gap-2 p-2">
        {/* Left Column (Stats & Atmospheric Signal Wave) */}
        <aside className="col-span-3 flex flex-col border rounded bg-black/10" style={{ borderColor: theme.border }}>
          <SystemMonitor theme={theme} />
        </aside>

        {/* Center Mainframe Console Terminal Area */}
        <section className="col-span-6 flex flex-col gap-2 min-h-0">
          {/* Interactive Shell Terminal */}
          <div 
            className="flex-1 flex flex-col border rounded p-4 relative shadow-2xl overflow-hidden backdrop-blur-[1px] transition-all"
            style={{ 
              borderColor: theme.primary, 
              backgroundColor: theme.panelBg,
              boxShadow: `0 0 25px ${theme.primaryGlow}`
            }}
          >
            {/* Top glass reflection corner details */}
            <div className="absolute top-2 right-3 flex space-x-1.5 opacity-60">
              <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: theme.primary }}></div>
              <div className="w-1.5 h-1.5 rounded-full bg-yellow-500"></div>
              <div className="w-1.5 h-1.5 rounded-full bg-green-500"></div>
            </div>

            {/* Main Terminal Buffer Screen */}
            <div className="flex-1 overflow-y-auto font-mono text-[11px] md:text-xs space-y-1.5 pr-2 min-h-0 scrollbar-thin">
              {terminalLogs.map((log) => {
                let colorClass = "text-white";
                if (log.type === "system") colorClass = "text-yellow-400 font-semibold";
                if (log.type === "error") colorClass = "text-red-400 font-bold animate-pulse";
                if (log.type === "ai") colorClass = "text-cyan-200 bg-cyan-950/20 p-2 border-l border-cyan-400 rounded-r";
                if (log.type === "input") colorClass = "opacity-75";

                return (
                  <div key={log.id} className={`whitespace-pre-wrap leading-relaxed ${colorClass}`}>
                    {log.type === "input" ? (
                      <span className="font-bold mr-1.5" style={{ color: theme.primary }}>$</span>
                    ) : null}
                    {log.text}
                  </div>
                );
              })}
              <div ref={logsEndRef} />
            </div>

            {/* Live Command Line Input */}
            <div className="mt-3 pt-2 border-t flex items-center space-x-2" style={{ borderColor: theme.border }}>
              <ChevronRight size={14} className="shrink-0 animate-pulse" style={{ color: theme.primary }} />
              <input
                ref={inputRef}
                type="text"
                value={commandInput}
                onChange={(e) => setCommandInput(e.target.value)}
                onKeyDown={handleKeyPress}
                placeholder="INPUT SECURE CONSOLE PAYLOAD COMMAND (try 'help' or 'ai hello')..."
                className="flex-1 bg-transparent border-none outline-none font-mono text-xs md:text-sm text-white select-text placeholder-gray-600"
                autoFocus
              />
              <span className="w-2 h-4 animate-pulse shrink-0" style={{ backgroundColor: theme.primary }}></span>
            </div>
          </div>
        </section>

        {/* Right Column (FileSystem & Processes & Decryptor & SoundPad) */}
        <aside className="col-span-3 flex flex-col gap-2 min-h-0">
          {/* Tabs Selector Header */}
          <div className="grid grid-cols-3 gap-1 bg-black/40 border p-1 rounded" style={{ borderColor: theme.border }}>
            <button
              onClick={() => {
                sound.playClick(1.0);
                setActiveRightTab("files");
              }}
              className="py-1 text-[8px] font-bold font-mono tracking-wider text-center uppercase cursor-pointer border rounded-sm transition-all"
              style={{
                backgroundColor: activeRightTab === "files" ? theme.primary : "transparent",
                color: activeRightTab === "files" ? "black" : theme.text,
                borderColor: activeRightTab === "files" ? theme.primary : "transparent"
              }}
            >
              FILES
            </button>
            <button
              onClick={() => {
                sound.playClick(1.0);
                setActiveRightTab("decryptor");
              }}
              className="py-1 text-[8px] font-bold font-mono tracking-wider text-center uppercase cursor-pointer border rounded-sm transition-all"
              style={{
                backgroundColor: activeRightTab === "decryptor" ? theme.primary : "transparent",
                color: activeRightTab === "decryptor" ? "black" : theme.text,
                borderColor: activeRightTab === "decryptor" ? theme.primary : "transparent"
              }}
            >
              DECRYPTOR
            </button>
            <button
              onClick={() => {
                sound.playClick(1.0);
                setActiveRightTab("soundpad");
              }}
              className="py-1 text-[8px] font-bold font-mono tracking-wider text-center uppercase cursor-pointer border rounded-sm transition-all"
              style={{
                backgroundColor: activeRightTab === "soundpad" ? theme.primary : "transparent",
                color: activeRightTab === "soundpad" ? "black" : theme.text,
                borderColor: activeRightTab === "soundpad" ? theme.primary : "transparent"
              }}
            >
              SOUND SYNTH
            </button>
          </div>

          <div className="flex-1 border rounded bg-black/10 min-h-0" style={{ borderColor: theme.border }}>
            {activeRightTab === "files" ? (
              <FileExplorer theme={theme} onOpenFileInTerminal={handleOpenFileInTerminal} />
            ) : activeRightTab === "decryptor" ? (
              <HackSimulator theme={theme} onSystemLog={(text, type) => {
                setTerminalLogs(prev => [
                  ...prev,
                  { id: Date.now().toString(), text, type }
                ]);
              }} />
            ) : (
              <SoundPad theme={theme} onSystemLog={(text, type) => {
                setTerminalLogs(prev => [
                  ...prev,
                  { id: Date.now().toString(), text, type }
                ]);
              }} />
            )}
          </div>
          <div className="h-56 border rounded bg-black/10 min-h-0" style={{ borderColor: theme.border }}>
            <ProcessManager theme={theme} />
          </div>
        </aside>
      </main>

      {/* 3. FOOTER: VIRTUAL KEYBOARD CONTAINER */}
      <footer className="p-2 border-t bg-black/40 backdrop-blur-sm" style={{ borderColor: theme.border }}>
        <VirtualKeyboard theme={theme} onKeyPress={handleVirtualKeyPress} />
      </footer>
    </div>
  );
}
